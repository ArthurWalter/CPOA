/**
 * 
 */
package TestListeMemoireDAO;

import static org.junit.jupiter.api.Assertions.*;

import java.sql.SQLException;

import org.junit.jupiter.api.Test;

import DAOFactory.DAOFactory;
import DAOFactory.DAOFactory.Persistance;
import POJO.TVA;

/**
 * @author arthu
 *
 */
class ListeMemoireTVADAOTest {

	TVA t  = new TVA(1,"testLib",20.0);
	TVA t2  = new TVA(1,"testLib2",10.0);
	DAOFactory daof = DAOFactory.getDAOFactory(Persistance.LISTEMEMOIRE);
	@Test
	void testGetInstance() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link ListeMemoireDAOFactory.ListeMemoireTVADAO#create(POJO.TVA)}.
	 * @throws SQLException 
	 */
	@Test
	void testCreate() throws SQLException {
		daof.getTVADAO().create(t);
		assertEquals(t, daof.getTVADAO().getById(t.getId_tva()));
	}

	/**
	 * Test method for {@link ListeMemoireDAOFactory.ListeMemoireTVADAO#update(POJO.TVA)}.
	 */
	@Test
	void testUpdate() throws SQLException{
		daof.getTVADAO().create(t);
		daof.getTVADAO().update(t2);
		assertEquals(t2, daof.getTVADAO().getById(t.getId_tva()));
	}

	/**
	 * Test method for {@link ListeMemoireDAOFactory.ListeMemoireTVADAO#delete(POJO.TVA)}.
	 */
	@Test
	void testDelete() throws SQLException{
		daof.getTVADAO().create(t);
		daof.getTVADAO().delete(t);
		assertNull(daof.getTVADAO().getById(1));
	}

	/**
	 * Test method for {@link ListeMemoireDAOFactory.ListeMemoireTVADAO#getById(int)}.
	 */
	@Test
	void testGetById() throws SQLException{
		daof.getTVADAO().create(t);
		assertNull(daof.getTVADAO().getById(1));
	}

	/**
	 * Test method for {@link ListeMemoireDAOFactory.ListeMemoireTVADAO#FindAll()}.
	 */
	@Test
	void testFindAll() throws SQLException{
		daof.getTVADAO().create(t);
		assertNull(daof.getTVADAO().getById(1));
	}

}
