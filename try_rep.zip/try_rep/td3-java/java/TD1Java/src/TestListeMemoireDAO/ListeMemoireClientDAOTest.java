/**
 * 
 */
package TestListeMemoireDAO;

import static org.junit.jupiter.api.Assertions.*;

import java.sql.SQLException;

import org.junit.jupiter.api.Test;

import DAOFactory.DAOFactory;
import DAOFactory.DAOFactory.Persistance;
import POJO.Client;

class ListeMemoireClientDAOTest {
	DAOFactory daof = DAOFactory.getDAOFactory(Persistance.LISTEMEMOIRE);
	Client c = new Client(1,"testprenom","testnom",50.0);
	Client c2 = new Client(1,"testprenom2","testnom2",60.0);
	@Test
	void testGetInstance() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link ListeMemoireDAOFactory.ListeMemoireClientDAO#create(POJO.Client)}.
	 * @throws SQLException 
	 */
	@Test
	void testCreate() throws SQLException {
		daof.getClientDAO().create(c);
		assertEquals(c, daof.getClientDAO().getById(c.getId_client()));
	}

	/**
	 * Test method for {@link ListeMemoireDAOFactory.ListeMemoireClientDAO#update(POJO.Client)}.
	 * @throws SQLException 
	 */
	@Test
	void testUpdate() throws SQLException {
		daof.getClientDAO().create(c);
		daof.getClientDAO().update(c2);
		assertEquals(c2, daof.getClientDAO().getById(c.getId_client()));
	}

	/**
	 * Test method for {@link ListeMemoireDAOFactory.ListeMemoireClientDAO#delete(POJO.Client)}.
	 * @throws SQLException 
	 */
	@Test
	void testDelete() throws SQLException {
		daof.getClientDAO().create(c);
		assertNull(daof.getClientDAO().getById(c.getId_client()));
		daof.getClientDAO().delete(c);
		
	}

	/**
	 * Test method for {@link ListeMemoireDAOFactory.ListeMemoireClientDAO#getById(int)}.
	 * @throws SQLException 
	 */
	@Test
	void testGetById() throws SQLException {
		daof.getClientDAO().create(c);
		assertNotNull(daof.getProduitDAO().getById(1));
	}

	/**
	 * Test method for {@link ListeMemoireDAOFactory.ListeMemoireClientDAO#FindAll()}.
	 * @throws SQLException 
	 */
	@Test
	void testFindAll() throws SQLException {
		daof.getClientDAO().create(c);
		assertNotNull(daof.getProduitDAO().getById(1));
	}

}
