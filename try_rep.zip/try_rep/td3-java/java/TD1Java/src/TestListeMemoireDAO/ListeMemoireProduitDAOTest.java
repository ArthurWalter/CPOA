/**
 * 
 */
package TestListeMemoireDAO;

import static org.junit.jupiter.api.Assertions.*;

import java.sql.SQLException;

import org.junit.jupiter.api.Test;

import DAOFactory.DAOFactory;
import DAOFactory.DAOFactory.Persistance;
import POJO.Produit;

class ListeMemoireProduitDAOTest {

	Produit p  = new Produit(1,"testnom",50.0,1);
	Produit p2 = new Produit(1, "testnom2", 60.0,2);
	DAOFactory daof = DAOFactory.getDAOFactory(Persistance.LISTEMEMOIRE);
	@Test
	void testGetInstance() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link ListeMemoireDAOFactory.ListeMemoireProduitDAO#create(POJO.Produit)}.
	 * @throws SQLException 
	 */
	@Test
	void testCreate() throws SQLException {
		daof.getProduitDAO().create(p);
		assertEquals(p, daof.getProduitDAO().getById(p.getId()));
	}

	/**
	 * Test method for {@link ListeMemoireDAOFactory.ListeMemoireProduitDAO#update(POJO.Produit)}.
	 * @throws SQLException 
	 */
	@Test
	void testUpdate() throws SQLException {
		daof.getProduitDAO().create(p);
		daof.getProduitDAO().update(p2);
		assertEquals(p2, daof.getProduitDAO().getById(p.getId()));
	}

	/**
	 * Test method for {@link ListeMemoireDAOFactory.ListeMemoireProduitDAO#delete(POJO.Produit)}.
	 */
	@Test
	void testDelete() throws SQLException {
		daof.getProduitDAO().create(p);
		daof.getProduitDAO().delete(p);
		assertNull(daof.getProduitDAO().getById(1));
	}

	/**
	 * Test method for {@link ListeMemoireDAOFactory.ListeMemoireProduitDAO#getById(int)}.
	 */
	@Test
	void testGetById() throws SQLException {
		daof.getProduitDAO().create(p);
		assertNotNull(daof.getProduitDAO().getById(1));
	}

	/**
	 * Test method for {@link ListeMemoireDAOFactory.ListeMemoireProduitDAO#FindAll()}.
	 */
	@Test
	void testFindAll() throws SQLException {
		daof.getProduitDAO().create(p);
		assertNotNull(daof.getProduitDAO().getById(1));
	}

}
