/**
 * 
 */
package TestListeMemoireDAO;

import static org.junit.jupiter.api.Assertions.*;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import org.junit.jupiter.api.Test;

import DAOFactory.DAOFactory;
import DAOFactory.DAOFactory.Persistance;
import POJO.Facture;

class ListeMemoireFactureDAOTest {

	public static DAOFactory daof;
	DateTimeFormatter format_date = DateTimeFormatter.ofPattern("dd/MM/yyyy");
	LocalDate dateDebut = LocalDate.parse("27/09/2018", format_date);
	LocalDate dateDebut2 = LocalDate.parse("06/10/2018", format_date);
	Facture f  = new Facture(1,1,dateDebut);
	Facture f2  = new Facture(1,1,dateDebut2);
	@Test
	void testGetInstance() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link ListeMemoireDAOFactory.ListeMemoireFactureDAO#create(POJO.Facture)}.
	 */
	@Test
	void testCreate() throws SQLException {
		daof=DAOFactory.getDAOFactory(Persistance.LISTEMEMOIRE);
		daof.getFactureDAO().create(f);
		assertEquals(f, daof.getFactureDAO().getById(f.getId_facture()));
	}

	/**
	 * Test method for {@link ListeMemoireDAOFactory.ListeMemoireFactureDAO#update(POJO.Facture)}.
	 */
	@Test
	void testUpdate() throws SQLException {
		daof=DAOFactory.getDAOFactory(Persistance.LISTEMEMOIRE);
		daof.getFactureDAO().create(f);
		daof.getFactureDAO().update(f2);
		assertEquals(f2, daof.getFactureDAO().getById(f.getId_facture()));
	}

	/**
	 * Test method for {@link ListeMemoireDAOFactory.ListeMemoireFactureDAO#delete(POJO.Facture)}.
	 */
	@Test
	void testDelete() throws SQLException {
		daof=DAOFactory.getDAOFactory(Persistance.LISTEMEMOIRE);
		daof.getFactureDAO().create(f);
		daof.getFactureDAO().delete(f);
		assertNull(daof.getFactureDAO().getById(1));
	}

	/**
	 * Test method for {@link ListeMemoireDAOFactory.ListeMemoireFactureDAO#getById(int)}.
	 */
	@Test
	void testGetById() throws SQLException {
		daof=DAOFactory.getDAOFactory(Persistance.LISTEMEMOIRE);
		daof.getFactureDAO().create(f);
		assertNotNull(daof.getFactureDAO().getById(1));
	}

	/**
	 * Test method for {@link ListeMemoireDAOFactory.ListeMemoireFactureDAO#findAll()}.
	 */
	@Test
	void testFindAll() throws SQLException {
		daof=DAOFactory.getDAOFactory(Persistance.LISTEMEMOIRE);
		daof.getFactureDAO().create(f);
		assertNotNull(daof.getFactureDAO().getById(1));
	}

}
