

package application;

import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.InputEvent;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

import java.net.URL;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ResourceBundle;

import DAOFactory.DAOFactory;
import POJO.Client;
import POJO.Facture;

public class ctrl_Facture extends Main implements Initializable, ChangeListener<Facture> {
	public DAOFactory daof=DAOFactory.getDAOFactory(Main.persistance);
	@FXML
	private Label lbl_resultat;
	public ObservableList<Facture> ol_facture=FXCollections.observableArrayList();
	public ObservableList<Client> ol_client=FXCollections.observableArrayList();
	@FXML
	private DatePicker DatePickerDate;
	@FXML
	private ComboBox<Client> cbb_client;
	@FXML
	private GridPane grid_pane;
	@FXML
	private TableView <Facture> tblFacture;
	@FXML
	private TableColumn<Facture, Integer> tblFacture_client;
	@FXML
	private TableColumn<Facture, LocalDate> tblFacture_date;
	@FXML
	private Button btn_ajouter;
	@FXML
	private Button btn_modifier;
	@FXML
	private Button btn_supprimer;	
	@FXML
	private Button btn_retour;
	
	public void AjouterItemListe() throws SQLException{
		Facture f = new Facture(this.cbb_client.getSelectionModel().getSelectedItem().getId_client(), 
				this.DatePickerDate.getValue());
		daof.getFactureDAO().create(f);
		synchro();
		this.DatePickerDate.setValue(null);
		this.cbb_client.setValue(null);
		this.cbb_client.requestFocus();
	}
	
	public static boolean isFloat(String s) {
	    try { 
	        Float.parseFloat(s); 
	    } catch(NumberFormatException e) { 
	        return false; 
	    } catch(NullPointerException e) {
	        return false;
	    }
	    return true;
	}
	
	@FXML
	public void Retour(InputEvent e){
		final Node source = (Node) e.getSource();
		final Stage stage = (Stage) source.getScene().getWindow();
		stage.close();
	}
	public void ModifierItemListe() throws SQLException {
		int id_facture=this.tblFacture.getSelectionModel().getSelectedItem().getId_facture();
		Facture f = new Facture(id_facture, 
				this.cbb_client.getSelectionModel().getSelectedItem().getId_client(), 
				(LocalDate) this.DatePickerDate.getValue());
		daof.getFactureDAO().update(f);
		synchro();
		this.cbb_client.setValue(null);
		this.DatePickerDate.setValue(null);
		this.cbb_client.requestFocus();
		this.btn_modifier.setDisable(true);
		this.btn_supprimer.setDisable(true);
	}
	public void SupprimerItemListe() throws SQLException {
		Facture f=this.tblFacture.getSelectionModel().getSelectedItem();
		daof.getFactureDAO().delete(f);
		synchro();
		this.cbb_client.setValue(null);
		this.DatePickerDate.setValue(null);
		this.cbb_client.requestFocus();
		this.btn_modifier.setDisable(true);
		this.btn_supprimer.setDisable(true);
	}
	
	public void ChoixItemListe() {
		Facture f=this.tblFacture.getSelectionModel().getSelectedItem();
		Client c_save=null;
		for (Client c : ol_client) {
			if(c.toString().contains("Client [id_client="+f.getId_client()+",")) {
				c_save=c;
				break;
			}
		}
		this.cbb_client.setValue(c_save);
		this.DatePickerDate.setValue(f.getDate_facture());
		this.btn_supprimer.setDisable(false);
		this.btn_modifier.setDisable(false);
	}

	@Override
	public void changed(ObservableValue<? extends Facture> arg0, Facture arg1, Facture arg2) {
		System.out.println(this.tblFacture.getSelectionModel().getSelectedItem());
	}

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		this.cbb_client.requestFocus();
		this.btn_modifier.setDisable(true);
		this.btn_supprimer.setDisable(true);
		try {
			this.ol_client.setAll(daof.getClientDAO().FindAll());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		this.cbb_client.setItems(this.ol_client);
		try {
			synchro();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void synchro() throws SQLException {
		this.ol_facture.setAll(daof.getFactureDAO().FindAll());
		this.tblFacture_client.setCellValueFactory(new PropertyValueFactory<Facture, Integer>("id_client"));
		this.tblFacture_date.setCellValueFactory(new PropertyValueFactory<Facture, LocalDate>("date_facture"));
		this.tblFacture.setItems(ol_facture);
	}
}
