package application;

import java.net.URL;
import java.sql.SQLException;
import java.util.List;
import java.util.ResourceBundle;

import DAOFactory.DAOFactory;
import DAOFactory.DAOFactory.Persistance;
import javafx.application.Application;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.InputEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import POJO.Client;
import POJO.TVA;

public class ctrl_Tva extends Main implements Initializable, ChangeListener<TVA>{
	public DAOFactory daof=DAOFactory.getDAOFactory(Main.persistance);
	public ObservableList<TVA> ol_tva=FXCollections.observableArrayList();
	@FXML
	private Label lbl_resultat;
	@FXML
	private TextField libelle_edit;
	@FXML
	private TextField taux_edit;
	@FXML
	private GridPane grid_pane;
	@FXML
	private TableView <TVA> tblTva;
	@FXML
	private TableColumn<TVA, String> tblTva_libelle;
	@FXML
	private TableColumn<TVA, Double> tblTva_tarif;
	
	@FXML
	private Button btn_supprimer;
	@FXML
	private Button btn_modifier;
	
	public void AjouterItemListe() throws SQLException{
		if(isFloat(taux_edit.getText()) && (isFloat(libelle_edit.getText()) == false)) {
			if((libelle_edit.getText() != null && libelle_edit.getText().trim().isEmpty() == false) && (taux_edit.getText() != null && taux_edit.getText().trim().isEmpty() == false)) {
				this.lbl_resultat.setTextFill(Color.BLACK);
				TVA T = new TVA(libelle_edit.getText(), Double.parseDouble(taux_edit.getText()));
						 lbl_resultat.setText(T.toString());
			}
		}
		else if(libelle_edit.getText().trim().isEmpty()) {
			this.lbl_resultat.setTextFill(Color.RED);
			this.lbl_resultat.setText("Nom du taux de tva mal saisi");
			if(taux_edit.getText().trim().isEmpty())
				this.lbl_resultat.setText(lbl_resultat.getText() + " et taux de tva mal saisi");
		}
		else if(taux_edit.getText().trim().isEmpty()) {
			this.lbl_resultat.setTextFill(Color.RED);
			this.lbl_resultat.setText("Taux de tva mal saisi");
		}
		else if(isFloat(libelle_edit.getText())) {
			this.lbl_resultat.setTextFill(Color.RED);
			this.lbl_resultat.setText("Nom du taux de tva mal saisi");
			if(isFloat(taux_edit.getText()) == false)
				this.lbl_resultat.setText(lbl_resultat.getText() + " et taux de tva mal saisi");
		}
		else if(isFloat(taux_edit.getText()) == false) {
			this.lbl_resultat.setTextFill(Color.RED);
			this.lbl_resultat.setText("Taux de tva mal saisi");
			this.lbl_resultat.autosize();
		}
		TVA T = new TVA(libelle_edit.getText(), Double.parseDouble(taux_edit.getText()));
		 lbl_resultat.setText(T.toString());
			daof.getTVADAO().create(T);
			synchro();//synchroniser les donnees de la BDD
			
		
	}
	
	public static boolean isFloat(String s) {
	    try { 
	        Float.parseFloat(s); 
	    } catch(NumberFormatException e) { 
	        return false; 
	    } catch(NullPointerException e) {
	        return false;
	    }
	    return true;
	}
	
	@FXML
	public void Retour(InputEvent e){
		final Node source = (Node) e.getSource();
		final Stage stage = (Stage) source.getScene().getWindow();
		stage.close();
	}
	
	public void SupprimerItemListe() throws SQLException {
			TVA t=this.tblTva.getSelectionModel().getSelectedItem();
			daof.getTVADAO().delete(t);
			synchro();
			this.libelle_edit.clear();
			this.taux_edit.clear();
			this.libelle_edit.requestFocus();
			this.btn_modifier.setDisable(true);
			this.btn_supprimer.setDisable(true);
	}
	
	public void ChoixItemListe() {
		TVA t=this.tblTva.getSelectionModel().getSelectedItem();
		this.libelle_edit.setText(t.getLibelle_tva());
		this.taux_edit.setText(String.valueOf(t.getTaux_tva()));
		
		
		this.tblTva_libelle.setText(t.getLibelle_tva());
		//this.tblTva_libelle.setText(t.getLibelle_tva());
		this.tblTva_tarif.setText(String.valueOf(t.getTaux_tva()));
		//this.tblTva_tarif.setText(String.valueOf(t.getTaux_tva()));
		// change les noms de colonne avec la valeur s�lectionn�
		
		btn_modifier.setDisable(false);
		btn_supprimer.setDisable(false);
	}

	@Override
	public void changed(ObservableValue<? extends TVA> arg0, TVA arg1, TVA arg2) {
		// TODO Auto-generated method stub
		System.out.println(this.tblTva.getSelectionModel().getSelectedItem());
	}

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		this.libelle_edit.requestFocus();
		this.btn_modifier.setDisable(true);
		this.btn_supprimer.setDisable(true);
		try {
			synchro();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	public void synchro() throws SQLException {
		this.ol_tva.setAll(daof.getTVADAO().FindAll());
		this.tblTva_libelle.setCellValueFactory(new PropertyValueFactory<TVA, String>("libelle_tva"));
		this.tblTva_tarif.setCellValueFactory(new PropertyValueFactory<TVA, Double>("taux_tva"));
		this.tblTva.setItems(ol_tva);
		
	}
	public void ModifierItemListe() throws NumberFormatException, SQLException {
		int id_tva=this.tblTva.getSelectionModel().getSelectedItem().getId_tva();
		daof.getTVADAO().update(new TVA(id_tva,
				this.libelle_edit.getText(), 
				Double.parseDouble(this.taux_edit.getText())));
		synchro();
		this.libelle_edit.clear();
		this.taux_edit.clear();
		this.libelle_edit.requestFocus();
		this.btn_modifier.setDisable(true);
		this.btn_supprimer.setDisable(true);
	}
	}

