package application;


import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.InputEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;

import DAOFactory.DAOFactory;
import POJO.Client;
import POJO.Produit;
import POJO.TVA;

public class ctrl_Client extends Main implements Initializable, ChangeListener<Client>{
	public DAOFactory daof=DAOFactory.getDAOFactory(Main.persistance);
	public ObservableList<Client> ol_client=FXCollections.observableArrayList();
	@FXML
	private Label lbl_resultat;
	@FXML
	private TextField nom_edit;
	@FXML
	private TextField prenom_edit;
	@FXML
	private TextField depenses_edit;
	@FXML
	private GridPane grid_pane;
	@FXML
	private TableView <Client> tblClient;
	@FXML
	private TableColumn<Client,String> tblClient_nom;	
	@FXML
	private TableColumn<Client,String> tblClient_prenom;
	@FXML
	private TableColumn<Client,Double> tblClient_depenses;
	@FXML
	private Button btn_supprimer;
	@FXML
	private Button btn_modifier; 
	
	
	public void AjouterItemListe() throws NumberFormatException, SQLException{
		if(isFloat(depenses_edit.getText()) && (isFloat(nom_edit.getText()) == false) && (isFloat(prenom_edit.getText()) == false)) {
			if((nom_edit.getText() != null && nom_edit.getText().trim().isEmpty() == false) && (prenom_edit.getText() != null && prenom_edit.getText().trim().isEmpty() == false) && (depenses_edit.getText() != null && depenses_edit.getText().trim().isEmpty() == false)) {
				this.lbl_resultat.setTextFill(Color.BLACK);
				Client C = new Client(nom_edit.getText(), prenom_edit.getText(), Float.parseFloat(depenses_edit.getText()));
						 lbl_resultat.setText(C.toString());
			}
		}
		else if(nom_edit.getText().trim().isEmpty()) {
			this.lbl_resultat.setTextFill(Color.RED);
			this.lbl_resultat.setText("Nom du client mal saisi");
			if(prenom_edit.getText().trim().isEmpty()) {
				this.lbl_resultat.setText(lbl_resultat.getText() + " et pr�nom du client mal saisi");
				if(depenses_edit.getText().trim().isEmpty())
					this.lbl_resultat.setText(lbl_resultat.getText() + " et d�penses mal saisies");
			}
			else if(depenses_edit.getText().trim().isEmpty())
				this.lbl_resultat.setText(lbl_resultat.getText() + " et d�penses mal saisies");
			this.lbl_resultat.autosize();
		}
		else if(prenom_edit.getText().trim().isEmpty()) {
			this.lbl_resultat.setTextFill(Color.RED);
			this.lbl_resultat.setText("Pr�nom du client mal saisi");
			if(depenses_edit.getText().trim().isEmpty())
				this.lbl_resultat.setText(lbl_resultat.getText() + " et d�penses mal saisies");
			this.lbl_resultat.autosize();
		}
		else if(depenses_edit.getText().trim().isEmpty()) {
			this.lbl_resultat.setTextFill(Color.RED);
			this.lbl_resultat.setText("D�penses mal saisies");
			this.lbl_resultat.autosize();
		}
		else if(isFloat(nom_edit.getText())) {
			this.lbl_resultat.setTextFill(Color.RED);
			this.lbl_resultat.setText("Nom du client mal saisi");
			if(isFloat(prenom_edit.getText())) {
				this.lbl_resultat.setText(lbl_resultat.getText() + " et pr�nom du client mal saisi");
				if(isFloat(depenses_edit.getText()) == false)
					this.lbl_resultat.setText(lbl_resultat.getText() + " et d�penses mal saisies");
			}
			else if(isFloat(depenses_edit.getText()) == false)
				this.lbl_resultat.setText(lbl_resultat.getText() + " et d�penses mal saisies");
			this.lbl_resultat.autosize();
		}
		else if(isFloat(depenses_edit.getText()) == false) {
			this.lbl_resultat.setTextFill(Color.RED);
			this.lbl_resultat.setText("D�penses mal saisies");
			this.lbl_resultat.autosize();
		}
		Client c = new Client(Integer.parseInt(this.depenses_edit.getText()) ,this.nom_edit.getText(), 
				this.prenom_edit.getText());
		daof.getClientDAO().create(c);
		synchro();
		this.nom_edit.clear();
		this.prenom_edit.clear();
		this.depenses_edit.clear();
		this.nom_edit.requestFocus();
	}
	
	public static boolean isFloat(String s) {
	    try { 
	        Float.parseFloat(s); 
	    } catch(NumberFormatException e) { 
	        return false; 
	    } catch(NullPointerException e) {
	        return false;
	    }
	    return true;
	}
	
	@FXML
	public void Retour(InputEvent e){
		final Node source = (Node) e.getSource();
		final Stage stage = (Stage) source.getScene().getWindow();
		stage.close();
	}
	
	public void SupprimerItemListe() throws SQLException {
		Client c=this.tblClient.getSelectionModel().getSelectedItem();
		daof.getClientDAO().delete(c);
		synchro();
		this.prenom_edit.clear();
		this.nom_edit.clear();
		this.depenses_edit.clear();
		this.nom_edit.requestFocus();
		this.btn_modifier.setDisable(true);
		this.btn_supprimer.setDisable(true);
	}
	
	public void ChoixItemListe() {
		Client c=this.tblClient.getSelectionModel().getSelectedItem();
		this.prenom_edit.setText(c.getPrenom());
		this.nom_edit.setText(c.getNom());
		this.depenses_edit.setText(String.valueOf(c.getCa_cumule()));
		
		this.tblClient_nom.setText(c.getNom());
		this.tblClient_prenom.setText(c.getPrenom());
		this.tblClient_depenses.setText(String.valueOf(c.getCa_cumule()));
		
		btn_modifier.setDisable(false);
		btn_supprimer.setDisable(false);
	}

	@Override
	public void changed(ObservableValue<? extends Client> arg0, Client arg1, Client arg2) {
		// TODO Auto-generated method stub
		System.out.println(this.tblClient.getSelectionModel().getSelectedItem());
	}
	public void ModifierItemListe() throws NumberFormatException, SQLException {
		int id_client=this.tblClient.getSelectionModel().getSelectedItem().getId_client();
		Client c = new Client(id_client, this.prenom_edit.getText(),  this.nom_edit.getText(),
				Double.parseDouble(this.depenses_edit.getText()));
		daof.getClientDAO().update(c);
		
		synchro();
		this.nom_edit.clear();
		this.prenom_edit.clear();
		this.depenses_edit.clear();
		this.nom_edit.requestFocus();
		this.btn_modifier.setDisable(true);
		this.btn_supprimer.setDisable(true);
	}
	public void synchro() throws SQLException {
		this.ol_client.setAll(daof.getClientDAO().FindAll());
		this.tblClient_nom.setCellValueFactory(new PropertyValueFactory<Client, String>("nom"));
		this.tblClient_prenom.setCellValueFactory(new PropertyValueFactory<Client, String>("prenom"));
		this.tblClient_depenses.setCellValueFactory(new PropertyValueFactory<Client, Double>("ca_cumule"));
		this.tblClient.setItems(ol_client);
	}

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		this.nom_edit.requestFocus();
		this.btn_modifier.setDisable(true);
		this.btn_supprimer.setDisable(true);
		try {
			synchro();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
