package application;
	
import java.io.IOException;
import java.net.URL;

import Connexion.ConnectionMySQL;
import DAOFactory.DAOFactory;
import DAOFactory.DAOFactory.Persistance;
import POJO.TVA;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import Connexion.ConnectionMySQL;


public class Main extends Application {
	public static Persistance persistance;
	@Override
	public void start(Stage primaryStage) {
		
		try {
			URL fxmlURL=getClass().getResource("/main.fxml");
			FXMLLoader fxmlLoader = new FXMLLoader(fxmlURL);
			Node root = fxmlLoader.load();
			Scene scene = new Scene((VBox) root,600,400);
			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			primaryStage.setScene(scene);
			primaryStage.setTitle("JavaFX");
			primaryStage.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}///VueListeMemoireDAO/vue/main.fxml
	
	public static void main(String[] args) {
		launch(args);
	}
	
	@FXML
	public void ctrl_Produitmethod() throws IOException {
		 Stage stage = new Stage();
	        Parent root = FXMLLoader.load(getClass().getResource("/produit.fxml"));
	        Scene scene = new Scene((VBox) root,900,800);
	        stage.setScene(scene);
	        stage.show();
	}
///VueListeMemoireDAO/vue/produit.fxml
	public void ctrl_Clientmethod() throws IOException {
		  Stage stage = new Stage();
	        Parent root = FXMLLoader.load(getClass().getResource("/client.fxml"));
	        Scene scene = new Scene((VBox) root,900,800);
	        stage.setScene(scene);
	        stage.show();
	}
	@FXML
	public void ctrl_Tvamethod() {
		Stage secondaryStage = new Stage();
		try {
			URL fxmlURL=getClass().getResource("/tva.fxml");
			FXMLLoader fxmlLoader = new FXMLLoader(fxmlURL);
			Node root = fxmlLoader.load();
			Scene scene = new Scene((VBox) root,900,800);
			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			secondaryStage.setScene(scene);
			secondaryStage.setTitle("TVA");
			secondaryStage.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	@FXML
	public void ctrl_Facturemethod() {
		Stage secondaryStage = new Stage();
		try {
			URL fxmlURL=getClass().getResource("/Facture.fxml");
			FXMLLoader fxmlLoader = new FXMLLoader(fxmlURL);
			Node root = fxmlLoader.load();
			Scene scene = new Scene((VBox) root,900,800);
			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			secondaryStage.setScene(scene);
			secondaryStage.setTitle("Facture");
			secondaryStage.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	@FXML
	ComboBox<String> cbbox_bddlm;
	@FXML
	GridPane gridpane;
	
	@SuppressWarnings("static-access")
	public void Ajout_bddlm(){
		this.cbbox_bddlm.setItems(FXCollections.observableArrayList("Base de données (en ligne)","Liste Mémoire (hors ligne)"));
		int id = cbbox_bddlm.getSelectionModel().getSelectedIndex();
		if(id==0) {
		gridpane.setVisible(true);
		gridpane.setDisable(false);
		cbbox_bddlm.setVisible(false);
		ConnectionMySQL.getInstance();
		this.persistance = Persistance.MYSQL;
		System.out.println("Persistance.mysql");
		}	
		else if(id==1) {
			gridpane.setVisible(true);
			gridpane.setDisable(false);
			cbbox_bddlm.setVisible(false);
			this.persistance = Persistance.LISTEMEMOIRE;
			System.out.println("Persistance.listememoire");
			}
	}
	public void Exit() {
		System.exit(0);
	}
}
