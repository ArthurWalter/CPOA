package application;
	
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;
import DAOFactory.DAOFactory;
import DAOFactory.DAOFactory.Persistance;
import POJO.Produit;
import POJO.TVA;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.stage.Stage;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.InputEvent;
import javafx.scene.paint.Color;


public class ctrl_Produit extends Main implements Initializable, ChangeListener<Produit>{
	public DAOFactory daof=DAOFactory.getDAOFactory(Main.persistance);
	public ObservableList<Produit> ol_prod=FXCollections.observableArrayList();
	public ObservableList<TVA> ol_tva=FXCollections.observableArrayList();
	
	@FXML
	public TableView<Produit> tblProduit;
	@FXML
	private TableColumn<Produit,String> tblProduit_libelle;	
	@FXML
	private TableColumn<Produit,Double> tblProduit_tarif;
	@FXML
	private TableColumn<Produit,Integer> tblProduit_tva;
	@FXML
	private Button btn_supprimer;
	@FXML
	private Button btn_modifier;
	@FXML
	private Label lbl_resultat;
	@FXML
	private TextField libelle_edit;
	@FXML
	private TextField tarif_edit;
	@FXML
	private ComboBox<TVA> cbx_tva;
	@FXML
	private Label l1;
	

	public static boolean isFloat(String s) {
	    try { 
	        Float.parseFloat(s); 
	    } catch(NumberFormatException e) { 
	        return false; 
	    } catch(NullPointerException e) {
	        return false;
	    }
	    return true;
	}

	
	public void AjouterItemListe() throws SQLException{
		
		if(isFloat(tarif_edit.getText()) && (isFloat(libelle_edit.getText()) == false)) {
			if(		(libelle_edit.getText() != null && libelle_edit.getText().trim().isEmpty() == false)
					&& (tarif_edit.getText() != null && tarif_edit.getText().trim().isEmpty() == false)
					&& cbx_tva.getSelectionModel().getSelectedIndex()!=-1) {
				this.lbl_resultat.setTextFill(Color.BLACK);
				int id = cbx_tva.getSelectionModel().getSelectedIndex();
				DAOFactory dao = DAOFactory.getDAOFactory(Persistance.MYSQL);
				TVA t = dao.getTVADAO().getById(id+1);	
				double f = Double.parseDouble(tarif_edit.getText());
				double d = (double) Math.round((f + t.getTaux_tva()/100 * f)*1000)/1000; // calcul du prix du produit
				String s = String.valueOf(d);
				this.lbl_resultat.setText(libelle_edit.getText() + " (" + tarif_edit.getText() + " euros)"+s);
				
			}
		}
		else // le cas de toutes les erreurs  : 
					if(libelle_edit.getText().trim().isEmpty()) {
						this.lbl_resultat.setTextFill(Color.RED);
						this.lbl_resultat.setText("Nom du produit mal saisi");
						if(tarif_edit.getText().trim().isEmpty() ) {
							this.lbl_resultat.setText(lbl_resultat.getText() + " et prix du produit mal saisi");
						if(cbx_tva.getSelectionModel().getSelectedIndex() == -1)
								this.lbl_resultat.setText(lbl_resultat.getText() + " et taux de tva mal saisi");
						}
						else if(cbx_tva.getSelectionModel().getSelectedIndex() == -1)
							this.lbl_resultat.setText(lbl_resultat.getText() + " et taux de tva mal saisi");
						this.lbl_resultat.autosize();
					}
					else if(tarif_edit.getText().trim().isEmpty()) {
						this.lbl_resultat.setTextFill(Color.RED);
						this.lbl_resultat.setText("Prix du produit mal saisi");
						if(cbx_tva.getSelectionModel().getSelectedIndex() == -1)
							this.lbl_resultat.setText(lbl_resultat.getText() + " et taux de tva mal saisi");
						this.lbl_resultat.autosize();
					}
					else if(cbx_tva.getSelectionModel().getSelectedIndex() == -1) {
						this.lbl_resultat.setTextFill(Color.RED);
						this.lbl_resultat.setText("Taux de tva mal saisi");
						this.lbl_resultat.autosize();
					}
					else if(libelle_edit.getText().trim().isEmpty() && (cbx_tva.getSelectionModel().getSelectedIndex() == -1)) {
						this.lbl_resultat.setTextFill(Color.RED);
						this.lbl_resultat.setText("Nom du produit et Taux de tva mal saisi");
						this.lbl_resultat.autosize();
					}
		Produit p =new Produit(this.libelle_edit.getText(), 
				Double.parseDouble(this.tarif_edit.getText()), 
				this.cbx_tva.getSelectionModel().getSelectedItem().getId_tva());
		/*Produit p = new Produit(this.cbx_tva.getSelectionModel().getSelectedItem().getId_tva(),
				this.libelle_edit.getText(), 
				Double.parseDouble(this.tarif_edit.getText()));*/
		daof.getProduitDAO().create(p);
		synchro();
		this.libelle_edit.clear();
		this.tarif_edit.clear();
		this.cbx_tva.setValue(null);
		this.libelle_edit.requestFocus();
	}

	@FXML
	public void Ajout_TVA() throws SQLException{
		this.cbx_tva.setItems(FXCollections.observableArrayList(daof.getTVADAO().FindAll()));
	}
	
	public void synchro() throws SQLException{
		this.ol_prod.setAll(daof.getProduitDAO().FindAll());
		tblProduit_libelle.setCellValueFactory(new PropertyValueFactory<Produit,String>("libelle_produit"));
		tblProduit_tarif.setCellValueFactory(new PropertyValueFactory<Produit,Double>("prix_produit")); // en String �a passe peut-�tre mieux
	 	tblProduit_tva.setCellValueFactory(new PropertyValueFactory<Produit,Integer>("taux_tva"));
		this.tblProduit.setItems(ol_prod);
		
	}

	@FXML
	public void Retour(InputEvent e){
		final Node source = (Node) e.getSource();
		final Stage stage = (Stage) source.getScene().getWindow();
		stage.close();
	}
	
	public void SupprimerItemListe() throws SQLException {
		Produit p=this.tblProduit.getSelectionModel().getSelectedItem();
		daof.getProduitDAO().delete(p);
		synchro();
		this.libelle_edit.clear();
		this.tarif_edit.clear();
		this.cbx_tva.setValue(null);
		this.libelle_edit.requestFocus();
		this.btn_modifier.setDisable(true);
		this.btn_supprimer.setDisable(true);
	}
	public void ModifierItemListe() throws SQLException{
		/*int id_prod=this.tblProduit.getSelectionModel().getSelectedItem().getId();
		String s = (String) libelle_edit.getText();
		double f = Double.parseDouble(tarif_edit.getText());
		Produit p = new Produit(id_prod, s, f);*/
		int id_prod=this.tblProduit.getSelectionModel().getSelectedItem().getId();
		Produit p =new Produit(id_prod,this.libelle_edit.getText(), 
				Double.parseDouble(this.tarif_edit.getText()), 
				this.cbx_tva.getSelectionModel().getSelectedItem().getId_tva());
		daof.getProduitDAO().update(p);
		synchro();
		this.libelle_edit.clear();
		this.tarif_edit.clear();
		this.cbx_tva.setValue(null);
		this.libelle_edit.requestFocus();
		this.btn_modifier.setDisable(true);
		this.btn_supprimer.setDisable(true);
	}
	
	public void ChoixItemListe() throws SQLException {
		Produit p=this.tblProduit.getSelectionModel().getSelectedItem();
		this.libelle_edit.setText(p.getLibelle_produit());
		this.tarif_edit.setText(String.valueOf(p.getPrix_produit()));
		TVA t=new TVA();
		for (TVA x : ol_tva) {
			if(x.toString().contains("id_tva="+p.getTaux_tva()+",")) {
				t=x;break;
			}
		}
		this.cbx_tva.setValue(t);
		this.btn_modifier.setDisable(false);
		this.btn_supprimer.setDisable(false);
		if(Main.persistance==Persistance.MYSQL) {
			if(tblProduit.getSelectionModel().getSelectedItem().getId()==2) {
			Image image = new Image("Images/mars.jpg",50,50,false,false);
			l1.setGraphic(new ImageView(image));
		}else if(tblProduit.getSelectionModel().getSelectedItem().getId()==3) {
			Image image = new Image("Images/chips.jpg",50,50,false,false);
			l1.setGraphic(new ImageView(image));
		}else if(tblProduit.getSelectionModel().getSelectedItem().getId()==4) {
			Image image = new Image("Images/coca.jpg",50,50,false,false);
			l1.setGraphic(new ImageView(image));
		}else if(tblProduit.getSelectionModel().getSelectedItem().getId()==5) {
			Image image = new Image("Images/fanta.jpg",50,50,false,false);
			l1.setGraphic(new ImageView(image));
		}else if(tblProduit.getSelectionModel().getSelectedItem().getId()==6) {
			Image image = new Image("Images/ice_tea.jpg",50,50,false,false);
			l1.setGraphic(new ImageView(image));
		}else if(tblProduit.getSelectionModel().getSelectedItem().getId()==7) {
			Image image = new Image("Images/monster.jpg",50,50,false,false);
			l1.setGraphic(new ImageView(image));
		}else if(tblProduit.getSelectionModel().getSelectedItem().getId()==8) {
			Image image = new Image("Images/oasis.jpg",50,50,false,false);
			l1.setGraphic(new ImageView(image));
		}else if(tblProduit.getSelectionModel().getSelectedItem().getId()==9) {
			Image image = new Image("Images/sucette.jpg",50,50,false,false);
			}
		}
	}

	@Override
	public void changed(ObservableValue<? extends Produit> arg0, Produit arg1, Produit arg2) {
		System.out.println(this.tblProduit.getSelectionModel().getSelectedItem());
	}


	@Override
	public void initialize(URL location, ResourceBundle resources) {
//	Image image = new Image("Images/test.jpg",30,30,true,true);
	//		l1.setGraphic(new ImageView(image));
		  this.libelle_edit.requestFocus();
			this.btn_modifier.setDisable(true);
			this.btn_supprimer.setDisable(true);
			try {
				synchro();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}//synchroniser les donnees de la BDD
			try {
				this.ol_tva.setAll(daof.getTVADAO().FindAll());
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			this.cbx_tva.setItems(ol_tva);
	}

	

	 
	

}
