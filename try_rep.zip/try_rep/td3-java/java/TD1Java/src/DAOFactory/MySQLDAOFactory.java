package DAOFactory;

import DAO.ClientDAO;
import DAO.FactureDAO;
import DAO.ProduitDAO;
import DAO.TVADAO;
import MySQLDAO.MySQLClientDAO;
import MySQLDAO.MySQLFactureDAO;
import MySQLDAO.MySQLProduitDAO;
import MySQLDAO.MySQLTVADAO;

public class MySQLDAOFactory extends DAOFactory{

	@Override
	public TVADAO getTVADAO() {
		return MySQLTVADAO.getInstance();
	}
	
	@Override
	public ClientDAO getClientDAO() {
		return MySQLClientDAO.getInstance();
	}
	
	@Override
	public FactureDAO getFactureDAO() {
		return MySQLFactureDAO.getInstance();
	}
	
	@Override
	public ProduitDAO getProduitDAO() {
		return MySQLProduitDAO.getInstance();
	}
	
}