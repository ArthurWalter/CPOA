package DAOFactory;

import DAO.ClientDAO;
import DAO.FactureDAO;
import DAO.ProduitDAO;
import DAO.TVADAO;
import ListeMemoireDAOFactory.ListeMemoireClientDAO;
import ListeMemoireDAOFactory.ListeMemoireFactureDAO;
import ListeMemoireDAOFactory.ListeMemoireProduitDAO;
import ListeMemoireDAOFactory.ListeMemoireTVADAO;

public class ListeMemoireDAOFactory extends DAOFactory {
	@Override
	public TVADAO getTVADAO() {
		return ListeMemoireTVADAO.getInstance();
	}
	
	@Override
	public ClientDAO getClientDAO() {
		return ListeMemoireClientDAO.getInstance();
	}
	
	@Override
	public ProduitDAO getProduitDAO() {
		return ListeMemoireProduitDAO.getInstance();
	}
	
	@Override
	public FactureDAO getFactureDAO() {
		return ListeMemoireFactureDAO.getInstance();
	}
}
