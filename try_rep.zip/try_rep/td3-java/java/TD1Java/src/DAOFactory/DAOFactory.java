package DAOFactory;

import DAO.ClientDAO;
import DAO.FactureDAO;
import DAO.ProduitDAO;
import DAO.TVADAO;

public abstract class DAOFactory {
	public enum Persistance{
		MYSQL,
		LISTEMEMOIRE,
	}
	public static DAOFactory getDAOFactory(Persistance cible) {
		DAOFactory daof = null;
		switch (cible) {
			case MYSQL: daof=new MySQLDAOFactory();
						break;
			case LISTEMEMOIRE: daof=new ListeMemoireDAOFactory();
						break;
		}
		return daof;
	}
	public abstract TVADAO getTVADAO();
	public abstract ClientDAO getClientDAO();
	public abstract ProduitDAO getProduitDAO();
	public abstract FactureDAO getFactureDAO();
		
}
