/**
 * 
 */
package TestMySQLDAO;

import static org.junit.jupiter.api.Assertions.*;

import java.sql.SQLException;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.jupiter.api.Test;

import Connexion.ConnectionMySQL;
import DAOFactory.DAOFactory;
import DAOFactory.DAOFactory.Persistance;
import MySQLDAO.MySQLClientDAO;
import POJO.Client;

class MySQLClientDAOTest {
	DAOFactory daof = DAOFactory.getDAOFactory(Persistance.MYSQL);
	Client c = new Client(1,"testprenom","testnom",50.0);
	Client c2 = new Client(1,"test2prenom","test2nom",60.0);

	@Test
	public void testGetInstance() {
		MySQLClientDAO m=MySQLClientDAO.getInstance();
		assertNotNull(m);
	}
	@BeforeClass
	public static void connection() {
		try {
			new ConnectionMySQL();
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
	@AfterClass
	public static void deconnection() {
		try {
			ConnectionMySQL.con.close();
			System.out.println("test deco");
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
	}
	
//	@Test
//	public void testGetById() throws SQLException {
//		daof.getClientDAO().create(c);
//		assertNotNull(daof.getClientDAO().getById(1));;
//	}

	@Test
	public void testCreate() throws SQLException {
		ConnectionMySQL.getInstance();
		daof.getClientDAO().create(c);
		assertEquals(c, daof.getClientDAO().getById(c.getId_client()));
		ConnectionMySQL.Deconnecter();
		// le assertEquals � une chaine en 1er param chez moi pcq mon getById me renvois un System.out.println comme �a
		
	}

	@Test
	public void testUpdate() throws SQLException {
		daof.getClientDAO().create(c);
		daof.getClientDAO().update(c2);
		assertEquals("1 test2prenom test2nom 60.0", daof.getClientDAO().getById(c.getId_client()));
	}

	@Test
	public void testDelete() throws SQLException {
		daof.getClientDAO().create(c);
		daof.getClientDAO().delete(c);
		assertNull(daof.getClientDAO().getById(c.getId_client()));
	}

	@Test
	public void testFindAll() throws SQLException {
		daof.getClientDAO().create(c);
		assertNotNull(daof.getClientDAO().FindAll());
	}

}
