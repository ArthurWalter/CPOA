/**
 * 
 */
package TestMySQLDAO;

import static org.junit.jupiter.api.Assertions.*;

import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import org.junit.jupiter.api.Test;

import Connexion.ConnectionMySQL;
import DAOFactory.DAOFactory;
import DAOFactory.DAOFactory.Persistance;
import POJO.Facture;

class MySQLFactureDAOTest {
	
	public static DAOFactory daof;
	DateTimeFormatter format_date = DateTimeFormatter.ofPattern("dd/MM/yyyy");
	LocalDate dateDebut = LocalDate.parse("27/09/2018", format_date);
	LocalDate dateDebut2 = LocalDate.parse("06/10/2018", format_date);
	@Test
	void testGetInstance() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link MySQLDAO.MySQLFactureDAO#getById(int)}.
	 * @throws SQLException 
	 */
	@Test
	void testGetById() throws SQLException {
		new ConnectionMySQL();
		daof=DAOFactory.getDAOFactory(Persistance.MYSQL);
		Facture f  = new Facture(1,1,dateDebut);
		daof.getFactureDAO().create(f);
		assertNotNull(daof.getProduitDAO().getById(1));
		ConnectionMySQL.Deconnecter();
	}

	/**
	 * Test method for {@link MySQLDAO.MySQLFactureDAO#create(POJO.Facture)}.
	 */
	@Test
	void testCreate() throws SQLException {
		new ConnectionMySQL();
		daof=DAOFactory.getDAOFactory(Persistance.MYSQL);
		Facture f  = new Facture(1,1,dateDebut);
		daof.getFactureDAO().create(f);
		assertEquals("1 1 27/09/2018", daof.getProduitDAO().getById(f.getId_facture()));
		// le assertEquals � une chaine en 1er param chez moi pcq mon getById me renvois un System.out.println comme �a
		ConnectionMySQL.Deconnecter();
	}

	/**
	 * Test method for {@link MySQLDAO.MySQLFactureDAO#update(POJO.Facture)}.
	 */
	@Test
	void testUpdate() throws SQLException {
		new ConnectionMySQL();
		daof=DAOFactory.getDAOFactory(Persistance.MYSQL);
		Facture f  = new Facture(1,1,dateDebut);
		daof.getFactureDAO().create(f);
		Facture f2  = new Facture(1,1,dateDebut2);
		daof.getFactureDAO().update(f2);
		assertEquals("1 1 06/10/2018", daof.getProduitDAO().getById(f.getId_facture()));
		ConnectionMySQL.Deconnecter();
	}

	/**
	 * Test method for {@link MySQLDAO.MySQLFactureDAO#delete(POJO.Facture)}.
	 */
	@Test
	void testDelete() throws SQLException{
		new ConnectionMySQL();
		daof=DAOFactory.getDAOFactory(Persistance.MYSQL);
		Facture f  = new Facture(1,1,dateDebut);
		daof.getFactureDAO().create(f);
		daof.getFactureDAO().delete(f);
		assertNull(daof.getProduitDAO().getById(1));
		// le assertEquals � une chaine en 1er param chez moi pcq mon getById me renvois un System.out.println comme �a
		ConnectionMySQL.Deconnecter();
	}

	/**
	 * Test method for {@link MySQLDAO.MySQLFactureDAO#FindAll()}.
	 * @throws SQLException 
	 */
	@Test
	void testFindAll() throws SQLException {
		new ConnectionMySQL();
		daof=DAOFactory.getDAOFactory(Persistance.MYSQL);
		Facture f  = new Facture(1,1,dateDebut);
		daof.getFactureDAO().create(f);
		assertNotNull(daof.getProduitDAO().getById(1));
		ConnectionMySQL.Deconnecter();
	}

}
