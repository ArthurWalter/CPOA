/**
 * 
 */
package TestMySQLDAO;

import static org.junit.jupiter.api.Assertions.*;

import java.sql.SQLException;

import org.junit.jupiter.api.Test;

import Connexion.ConnectionMySQL;
import DAOFactory.DAOFactory;
import DAOFactory.DAOFactory.Persistance;
import POJO.TVA;

/**
 * @author arthu
 *
 */
class MySQLTVADAOTest {

	public static DAOFactory daof;
	
	@Test
	void testGetInstance() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link MySQLDAO.MySQLTVADAO#getById(int)}.
	 * @throws SQLException 
	 */
	@Test
	void testGetById() throws SQLException {
		new ConnectionMySQL();
		daof=DAOFactory.getDAOFactory(Persistance.MYSQL);
		TVA t  = new TVA(1,"testLib",20.0);
		daof.getTVADAO().create(t);
		assertNotNull(daof.getTVADAO().getById(1));
		ConnectionMySQL.Deconnecter();
	}

	/**
	 * Test method for {@link MySQLDAO.MySQLTVADAO#create(POJO.TVA)}.
	 * @throws SQLException 
	 */
	@Test
	void testCreate() throws SQLException {
		new ConnectionMySQL();
		daof=DAOFactory.getDAOFactory(Persistance.MYSQL);
		TVA t  = new TVA(1,"testLib",20.0);
		daof.getTVADAO().create(t);
		assertEquals("1 testLib 20.0", daof.getTVADAO().getById(t.getId_tva()));
		ConnectionMySQL.Deconnecter();
	}

	/**
	 * Test method for {@link MySQLDAO.MySQLTVADAO#update(POJO.TVA)}.
	 */
	@Test
	void testUpdate() throws SQLException{
		new ConnectionMySQL();
		daof=DAOFactory.getDAOFactory(Persistance.MYSQL);
		TVA t  = new TVA(1,"testLib",20.0);
		daof.getTVADAO().create(t);
		TVA t2  = new TVA(1,"testLib2",30.0);
		daof.getTVADAO().update(t2);
		assertEquals("1 testLib2 30.0", daof.getTVADAO().getById(t.getId_tva()));
		ConnectionMySQL.Deconnecter();
	}

	/**
	 * Test method for {@link MySQLDAO.MySQLTVADAO#delete(POJO.TVA)}.
	 */
	@Test
	void testDelete() throws SQLException{
		new ConnectionMySQL();
		daof=DAOFactory.getDAOFactory(Persistance.MYSQL);
		TVA t  = new TVA(1,"testLib",20.0);
		daof.getTVADAO().create(t);
		daof.getTVADAO().delete(t);
		assertNull(daof.getTVADAO().getById(1));
		ConnectionMySQL.Deconnecter();
	}

	/**
	 * Test method for {@link MySQLDAO.MySQLTVADAO#FindAll()}.
	 * @throws SQLException 
	 */
	@Test
	void testFindAll() throws SQLException {
		new ConnectionMySQL();
		daof=DAOFactory.getDAOFactory(Persistance.MYSQL);
		TVA t  = new TVA(1,"testLib",20.0);
		daof.getTVADAO().create(t);
		assertNotNull(daof.getTVADAO().getById(1));
		ConnectionMySQL.Deconnecter();
	}

}
