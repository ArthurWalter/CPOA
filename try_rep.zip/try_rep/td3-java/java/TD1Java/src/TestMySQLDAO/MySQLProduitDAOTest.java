
package TestMySQLDAO;

import static org.junit.jupiter.api.Assertions.*;

import java.sql.SQLException;

import org.junit.jupiter.api.Test;

import Connexion.ConnectionMySQL;
import DAOFactory.DAOFactory;
import DAOFactory.DAOFactory.Persistance;
import POJO.Produit;

class MySQLProduitDAOTest {

	public static DAOFactory daof;
	
	@Test
	void testGetInstance() {
		fail("Not yet implemented");
	}


	@Test
	void testGetById() throws SQLException {
		new ConnectionMySQL();
		daof=DAOFactory.getDAOFactory(Persistance.MYSQL);
		Produit p  = new Produit(1,"testnom",50.0,1);
		daof.getProduitDAO().create(p);
		assertNotNull(daof.getProduitDAO().getById(1));
		ConnectionMySQL.Deconnecter();
	}

	/**
	 * Test method for {@link MySQLDAO.MySQLProduitDAO#create(POJO.Produit)}.
	 * @throws SQLException 
	 */
	@Test
	void testCreate() throws SQLException {
		new ConnectionMySQL();
		daof=DAOFactory.getDAOFactory(Persistance.MYSQL);
		Produit p  = new Produit(1,"testnom",50.0,1);
		daof.getProduitDAO().create(p);
		assertEquals("1 50.0 testnom 1", daof.getProduitDAO().getById(p.getId()));
		// le assertEquals � une chaine en 1er param chez moi pcq mon getById me renvois un System.out.println comme �a
		ConnectionMySQL.Deconnecter();
	}

	/**
	 * Test method for {@link MySQLDAO.MySQLProduitDAO#update(POJO.Produit)}.
	 * @throws SQLException 
	 */
	@Test
	void testUpdate() throws SQLException {
		new ConnectionMySQL();
		daof=DAOFactory.getDAOFactory(Persistance.MYSQL);
		Produit p  = new Produit(1,"testnom",50.0,1);
		daof.getProduitDAO().create(p);
		Produit p2 = new Produit(1, "testnom2", 60.0,2);
		daof.getProduitDAO().update(p2);
		assertEquals("1 60.0 testnom2 2", daof.getProduitDAO().getById(p.getId()));
		ConnectionMySQL.Deconnecter();
	}

	/**
	 * Test method for {@link MySQLDAO.MySQLProduitDAO#delete(POJO.Produit)}.
	 * @throws SQLException 
	 */
	@Test
	void testDelete() throws SQLException {
		new ConnectionMySQL();
		daof=DAOFactory.getDAOFactory(Persistance.MYSQL);
		Produit p  = new Produit(1,"testnom",50.0,1);
		daof.getProduitDAO().create(p);
		daof.getProduitDAO().delete(p);
		assertNull(daof.getProduitDAO().getById(1));
		ConnectionMySQL.Deconnecter();
	}

	/**
	 * Test method for {@link MySQLDAO.MySQLProduitDAO#FindAll()}.
	 * @throws SQLException 
	 */
	@Test
	void testFindAll() throws SQLException {
		new ConnectionMySQL();
		daof=DAOFactory.getDAOFactory(Persistance.MYSQL);
		Produit p  = new Produit(1,"testnom",50.0,1);
		daof.getProduitDAO().create(p);
		assertNotNull(daof.getProduitDAO().getById(1));
		ConnectionMySQL.Deconnecter();
	}

}
