package POJO;

public class Ligne_Facture {

}
