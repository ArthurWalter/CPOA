package POJO;

public class Client{
	private int id_client;
	private String prenom;
	private String nom;
	private double ca_cumule;
	

	public int getId_client() {
		return id_client;
	}
	public void setId_client(int id_client) {
		this.id_client = id_client;
	}
	
	public String getPrenom() {
		return prenom;
	}
	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}
	
	public String getNom() {
		return nom;
	}
	public void setNom(String nom) {
		this.nom = nom;
	}
	
	public double getCa_cumule() {
		return ca_cumule;
	}
	public void setCa_cumule(double d) {
		this.ca_cumule = d;
	}
	
	public Client(int id_client, String prenom, String nom) {
		super();
		this.id_client = id_client;
		this.prenom = prenom;
		this.nom = nom;
	}

	public Client() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Client(String prenom, String nom) {
		super();
		this.prenom = prenom;
		this.nom = nom;
	}

	public Client(int id_client) {
		super();
		this.id_client = id_client;
	}

	public Client(String prenom, String nom, float ca_cumule) {
		super();
		this.prenom = prenom;
		this.nom = nom;
		this.ca_cumule = ca_cumule;
	}

	public String toString() {
		return "Client [id_client=" + id_client + ", prenom=" + prenom + ", nom=" + nom + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		long temp;
		temp = Double.doubleToLongBits(ca_cumule);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + id_client;
		result = prime * result + ((nom == null) ? 0 : nom.hashCode());
		result = prime * result + ((prenom == null) ? 0 : prenom.hashCode());
		return result;
	}

	public Client(int id_client, String prenom, String nom, double ca_cumule) {
		super();
		this.id_client = id_client;
		this.prenom = prenom;
		this.nom = nom;
		this.ca_cumule = ca_cumule;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Client other = (Client) obj;
		if (Double.doubleToLongBits(ca_cumule) != Double.doubleToLongBits(other.ca_cumule))
			return false;
		if (id_client != other.id_client)
			return false;
		if (nom == null) {
			if (other.nom != null)
				return false;
		} else if (!nom.equals(other.nom))
			return false;
		if (prenom == null) {
			if (other.prenom != null)
				return false;
		} else if (!prenom.equals(other.prenom))
			return false;
		return true;
	}

	
	
	
}