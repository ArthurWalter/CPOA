package POJO;

import java.time.LocalDate;

public class Facture {
	private int id_facture;
	private int id_client;
	private LocalDate date_facture;
	public Facture() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Facture(int id_client, LocalDate date_facture) {
		super();
		this.id_client = id_client;
		this.date_facture = date_facture;
	}
	public int getId_facture() {
		return id_facture;
	}//test
	public void setId_facture(int id_facture) {
		this.id_facture = id_facture;
	}
	public int getId_client() {
		return id_client;
	}
	public void setId_client(int id_client) {
		this.id_client = id_client;
	}
	public LocalDate getDate_facture() {
		return date_facture;
	}
	public void setDate_facture(LocalDate date_facture) {
		this.date_facture = date_facture;
	}
	public Facture(int id_facture, int id_client) {
		super();
		this.id_facture = id_facture;
		this.id_client = id_client;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((date_facture == null) ? 0 : date_facture.hashCode());
		result = prime * result + id_client;
		result = prime * result + id_facture;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Facture other = (Facture) obj;
		if (date_facture == null) {
			if (other.date_facture != null)
				return false;
		} else if (!date_facture.equals(other.date_facture))
			return false;
		if (id_client != other.id_client)
			return false;
		if (id_facture != other.id_facture)
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "Facture [id_facture=" + id_facture + ", id_client=" + id_client + ", date_facture=" + date_facture
				+ "]";
	}
	public Facture(int id_facture, int id_client, LocalDate date_facture) {
		super();
		this.id_facture = id_facture;
		this.id_client = id_client;
		this.date_facture = date_facture;
	}
	public Facture(int id_facture) {
		super();
		this.id_facture = id_facture;
	}
	
	
}
