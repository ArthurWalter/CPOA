package POJO;

public class Produit{
	
	
	private int id;
	private String libelle_produit;
	private double prix_produit;
	private int taux_tva;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getNom_produit() {
		return libelle_produit;
	}
	
	public Produit(int id, String libelle_produit, double prix_produit) {
		super();
		this.id = id;
		this.libelle_produit = libelle_produit;
		this.prix_produit = prix_produit;
	}
	public Produit(int id, String libelle_produit, int taux_tva) {
		super();
		this.id = id;
		this.libelle_produit = libelle_produit;
		this.taux_tva = taux_tva;
	}
	public void setNom_produit(String nom_produit) {
		this.libelle_produit = nom_produit;
	}
	public double getPrix_produit() {
		return prix_produit;
	}
	
	public String getLibelle_produit() {
		return libelle_produit;
	}
	public void setLibelle_produit(String libelle_produit) {
		this.libelle_produit = libelle_produit;
	}
	public void setPrix_produit(double prix_produit) {
		this.prix_produit = prix_produit;
	}
	public int getTaux_tva() {
		return taux_tva;
	}
	public void setTaux_tva(int taux_tva) {
		this.taux_tva = taux_tva;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + id;
		result = prime * result + ((libelle_produit == null) ? 0 : libelle_produit.hashCode());
		long temp;
		temp = Double.doubleToLongBits(prix_produit);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + taux_tva;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Produit other = (Produit) obj;
		if (id != other.id)
			return false;
		if (libelle_produit == null) {
			if (other.libelle_produit != null)
				return false;
		} else if (!libelle_produit.equals(other.libelle_produit))
			return false;
		if (Double.doubleToLongBits(prix_produit) != Double.doubleToLongBits(other.prix_produit))
			return false;
		if (taux_tva != other.taux_tva)
			return false;
		return true;
	}
	public Produit(int id, String nom_produit, double d, int taux_tva) {
		super();
		this.id = id;
		this.libelle_produit = nom_produit;
		this.prix_produit = d;
		this.taux_tva = taux_tva;
	}
	public Produit() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Produit(int id) {
		super();
		this.id = id;
	}
	public Produit(String nom_produit, double d) {
		super();
		this.libelle_produit = nom_produit;
		this.prix_produit = d;
	}
	public Produit(String libelle_produit, double prix_produit, int taux_tva) {
		super();
		this.libelle_produit = libelle_produit;
		this.prix_produit = prix_produit;
		this.taux_tva = taux_tva;
	}
	
	
}