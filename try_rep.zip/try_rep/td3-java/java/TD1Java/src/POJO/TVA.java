package POJO;


public class TVA{
	private int id_tva;
	private String libelle_tva;
	private double taux_tva;
	
	public int getId_tva() {
		return id_tva;
	}
	public void setId_tva(int id_tva) {
		this.id_tva = id_tva;
	}
	public String getLibelle_tva() {
		return libelle_tva;
	}
	public void setLibelle_tva(String libelle_tva) {
		this.libelle_tva = libelle_tva;
	}
	public TVA(String libelle_tva, double r) {
		super();
		this.libelle_tva = libelle_tva;
		this.taux_tva = r;
	}
	public double getTaux_tva() {
		return taux_tva;
	}
	public void setTaux_tva(double taux_tva) {
		this.taux_tva = taux_tva;
	}
	
	
	@Override
	public String toString() {
		return "TVA [id_tva=" + id_tva + ", libelle_tva=" + libelle_tva + ", taux_tva=" + taux_tva + "]";
	}
	public TVA(double taux_tva) {
		super();
		this.taux_tva = taux_tva;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TVA other = (TVA) obj;
		if (id_tva != other.id_tva)
			return false;
		if (libelle_tva == null) {
			if (other.libelle_tva != null)
				return false;
		} else if (!libelle_tva.equals(other.libelle_tva))
			return false;
		if (Double.doubleToLongBits(taux_tva) != Double.doubleToLongBits(other.taux_tva))
			return false;
		return true;
	}
	public TVA() {
		super();
		// TODO Auto-generated constructor stub
	}
	public TVA(int id_tva, String libelle_tva, double taux_tva) {
		super();
		this.id_tva = id_tva;
		this.libelle_tva = libelle_tva;
		this.taux_tva = taux_tva;
	}
	public TVA(int id_tva, String libelle_tva) {
		super();
		this.id_tva = id_tva;
		this.libelle_tva = libelle_tva;
	}
	
	public TVA(String libelle_tva) {
		super();
		this.libelle_tva = libelle_tva;
	}
	public TVA(int id_tva) {
		super();
		this.id_tva = id_tva;
	}
	
	
}