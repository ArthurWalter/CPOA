package Connexion;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;//test

public class ConnectionMySQL {
	public static Connection con= null;
	private static ConnectionMySQL instance;

	public ConnectionMySQL() {
		Connecter();
	}
	public static ConnectionMySQL getInstance() {
		if(instance==null) {
			instance=new ConnectionMySQL();
		}
		return instance;
	}
	public void Connecter() {
		Properties accesBdd = new Properties();
		File fBdd = new File("Properties.xml");
		try {
		FileInputStream source = new FileInputStream(fBdd);
		accesBdd.loadFromXML(source);
		 String url = "jdbc:mysql://localhost:3306/walter59u_td1java?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=Europe/Paris"; // localhost ou infodb.iutmetz.univ-lorraine.fr
		String log=accesBdd.getProperty("login");
		String psw=accesBdd.getProperty("pass");

		con=DriverManager.getConnection(url, log, psw);
//		con=DriverManager.getConnection(URL, "walter59u_appli", "31716872");
		System.out.println("MySQL Connect�");
		}
		catch (IOException ioe) {
			System.out.println(ioe.getMessage());
			ioe.printStackTrace();
		}
		catch (SQLException e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
	}
	public static void Deconnecter() {
		try {
			if(con!=null) {
				con.close();
				System.out.println("MySQL D�connect�");
			}
		}
		catch (SQLException sqle) {
			sqle.printStackTrace();
			System.out.println(sqle.getMessage());
		}
}
}
