package Connexion;

import java.sql.*;
public class Connexion{
	@SuppressWarnings("unused")
	private int no;
	@SuppressWarnings("unused")
	private String nom;

	public Connection creeConnexion(){
		 String url = "jdbc:mysql://localhost:3306/walter59u_td1java?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=Europe/Paris"; // localhost ou infodb.iutmetz.univ-lorraine.fr
		 String login = "walter59u_appli";
		 String pwd = "31716872";
		 Connection maConnexion = null;
		 //test 2
		 try {
			 maConnexion = DriverManager.getConnection(url, login, pwd);
		 }
		 catch (SQLException sqle){
			 System.out.println("Erreur connexion" + sqle.getMessage());
		 }
		 return maConnexion;
	}

	public void uneRequete(){
		try{
			Connection laConnexion = creeConnexion();
			Statement requete = laConnexion.createStatement();
			ResultSet res = requete.executeQuery("select no_etudiant, nom_etudiant from etudiant");
			while (res.next()){
				no = res.getInt(1);
				nom = res.getString("nom_etudiant");
			}
			if (res != null)
				res.close();
			if (requete != null)
				requete.close();
			if (laConnexion != null)
				laConnexion.close();
		}
		catch (SQLException sqle){
			System.out.println("Pb select" + sqle.getMessage());
		}
	}
}
