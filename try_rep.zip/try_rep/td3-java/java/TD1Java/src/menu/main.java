package menu;
import java.sql.SQLException;

public class main {

	@SuppressWarnings("unused")
	private static Menu m;

	public static void main(String[] args) throws SQLException{
		m = new Menu();
	}
}