package menu;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.InputMismatchException;
import java.util.Scanner;

import Connexion.ConnectionMySQL;
import DAOFactory.DAOFactory;
import DAOFactory.DAOFactory.Persistance;
import POJO.Client;
import POJO.Facture;
import POJO.Produit;
import POJO.TVA;

public class Menu{
	private static final char[] InputMismatchException = null;
	@SuppressWarnings("unused")
	private static Menu m;
	@SuppressWarnings("unused")
	public static Scanner sc=new Scanner(System.in);
	public static DAOFactory daof;
	public static int choix;
	public static String typebdd;
	private static DateTimeFormatter formatage=DateTimeFormatter.ofPattern("dd/MM/yyyy");
	
	public Menu() {
		MenuBDD();
	}
	public static void MenuBDD(){
		System.out.println("Voulez-vous acc�der � la BDD"
				+ "MySQL : 1 ou ListeM�moire : 2? (Quitter 0)");
		choix=0;
		try{
			choix=sc.nextInt();
			switch (choix) 
			{
			case 1: typebdd="MySQL";
					System.out.println("MySQL connection...");
					new ConnectionMySQL(); // !! normalement c'est ConnectionMySQL() !!
					daof=DAOFactory.getDAOFactory(Persistance.MYSQL);
					MainMenu();break; // test3
					
			case 2: typebdd="ListeMemoire";
					daof=DAOFactory.getDAOFactory(Persistance.LISTEMEMOIRE);
					MainMenu();break;
					
			case 0: System.out.println("Non");
					System.exit(0);
					break;
			default: System.out.println("Erreur"); 
			}
		}
		catch(Exception e) {
			System.out.println("Erreur de saisie, veuillez saisir 1 ou 2 ou 0");
			System.out.println(e.getMessage());
			MenuBDD();//en cas d'erreur, on rapelle MenuPrincipal()
		}
		
	}
	public static void MainMenu() throws SQLException {
	System.out.println("Tapez 1 pour acc�der au menu des produits"
			+ "\nTapez 2 pour acc�der au menu des clients"
			+ "\nTapez 3 pour acc�der au menu des taux de TVA"
			+ "\nTapez 4 pour acc�der au menu des factures"
			+ "\nTapez 5 pour quitter le programme");
	sc = new Scanner(System.in);
	Integer choix = sc.nextInt();
		switch(choix){
			case 1 : MenuProduits();break;
			case 2 : MenuClient();break;
			case 3 : MenuTVA();break;
			case 4 : MenuFacture();break;
			case 5 : Quitter();break;
			default: System.out.println("Erreur de saisie veuillez recommencer.");
			m = new Menu();break;
		}
	}
	
	private static void MenuFacture() throws SQLException {
		System.out.println("Tapez 1 pour afficher toutes les factures"
				+ "\nTapez 2 pour ajouter une facture"
				+ "\nTapez 3 pour supprimer une facture"
				+ "\nTapez 4 pour modifier une facture"
				+ "\nTapez 5 pour getById une facture"
				+ "\nTapez 6 pour revenir au menu principal");
		sc = new Scanner(System.in);
		Integer choix = sc.nextInt();
			switch(choix){
				case 1 : daof.getFactureDAO().FindAll();MenuFacture();break;
				
				case 2 : 
				System.out.println("Entrer un id_facture:");
				int id_facture=sc.nextInt();
				System.out.println("Entrer un id_client:");
				int id_client=sc.nextInt();
				System.out.println("Entrer une date sous forme (dd/MM/yyyy):");
				sc.nextLine(); // vide la m�m du scanner
				LocalDate date_facture=LocalDate.parse(sc.nextLine(), formatage);
				Facture f1 = new Facture(id_facture, id_client, date_facture);
				daof.getFactureDAO().create(f1);
				MenuFacture();
				break;
				
				case 3 :
					System.out.println("Supprimer : Entrer un id_facture:");
					id_facture=sc.nextInt();
					Facture f2 = new Facture(id_facture);
					daof.getFactureDAO().delete(f2); 
					MenuFacture();
					break;
				
				case 4 : 
					System.out.println("Entrer un id_facture:");
					id_facture=sc.nextInt();
					System.out.println("Entrer un id_client:");
					id_client=sc.nextInt();
					System.out.println("Entrer une date sous forme (dd/MM/yyyy):");
					sc.nextLine();// vide la m�m du scanner
					date_facture=LocalDate.parse(sc.nextLine(), formatage);
					Facture f3 = new Facture(id_facture, id_client, date_facture);
					daof.getFactureDAO().update(f3);
					MenuFacture();
				break;
				
				case 5 :
					sc = new Scanner(System.in);
					System.out.println("saisir l'ID de la facture que vous voulez voir:"); 
					int id_fact = sc.nextInt();
					daof.getFactureDAO().getById(id_fact);
					MenuProduits();
					break;
				
				case 6 : m = new Menu();break;
				default: ErreurSaisie();MenuProduits();break;
				}
		
	}

	public static void MenuProduits() throws SQLException{
		System.out.println("Tapez 1 pour afficher tous les produits"
				+ "\nTapez 2 pour ajouter un produit"
				+ "\nTapez 3 pour supprimer un produit"
				+ "\nTapez 4 pour modifier un produit"
				+ "\nTapez 5 pour getById un produit"
				+ "\nTapez 6 pour revenir au menu principal");
		sc = new Scanner(System.in);
		Integer choix = sc.nextInt();
			switch(choix){
				case 1 : daof.getProduitDAO().FindAll();;MenuProduits();break;
				case 2 :
	
					sc = new Scanner(System.in);
					System.out.println("Saisir le libelle du produit:");
					String libelle =sc.next();
					System.out.println("Saisir le prix du produit:");
					float prix = sc.nextFloat();
					System.out.println("Saisir l'ID TVA du produit:");
					Integer id = sc.nextInt();
					Produit p3 = new Produit(id,libelle,prix);
					daof.getProduitDAO().create(p3);MenuProduits();break;
				
				case 3 : 
					Scanner sc1 = new Scanner(System.in);
					System.out.println("Saisir l'ID du produit que vous voulez supprimer:"); 
					Integer id_prod1 = sc1.nextInt(); // on rename les var id_prod1 car on ne peut utiliser 2 fois le meme nom de var
					Produit p1 = new Produit(id_prod1);
					daof.getProduitDAO().delete(p1);
					MenuProduits();
					break;

				case 4 : 
					sc = new Scanner(System.in);
					sc = new Scanner(System.in);
					System.out.println("Saisir l'ID du produit que vous voulez modifier:"); 
					Integer id_prod2 = sc.nextInt();
					System.out.println("Saisir le libelle du produit:");
					String libelle_prod =sc.next();
					System.out.println("Saisir le prix du produit:");
					float prix_prod =sc.nextFloat();
					System.out.println("Saisir l'ID TVA du produit:");
					Integer id_tva_prod =sc.nextInt();
					Produit p2 = new Produit(id_prod2,libelle_prod,prix_prod,id_tva_prod); // on cr�e un objet que l'on envoi dans la classe DAO pour ensuite utiliser la m�thode qui lui est li�e.
					daof.getProduitDAO().update(p2);
					MenuProduits();break;
				
				case 5 :
					sc = new Scanner(System.in);
					System.out.println("saisir l'ID du produit que vous voulez voir:"); 
					int id_prod = sc.nextInt();
					daof.getProduitDAO().getById(id_prod);
					MenuProduits();
					break;
					
				case 6 : m = new Menu();break;
				default: ErreurSaisie();MenuProduits();break;
				}
	}
	
	public static void MenuClient() throws SQLException{		
		System.out.println("Tapez 1 pour Afficher tous les clients\nTapez 2 pour ajouter un client"
				+ "\nTapez 3 pour supprimer un client"
				+ "\nTapez 4 pour modifier un client"
				+"\nTapez 5 pour getById"
				+"\nTapez 6 pour revenir au menu principal");
		sc = new Scanner(System.in);
		Integer choix = sc.nextInt();
			switch(choix){
				case 1 : daof.getClientDAO().FindAll();MenuClient();break;
				case 2 :
					sc = new Scanner(System.in);
					sc = new Scanner (System.in);
					System.out.println("Saisir le pr�nom du client:");
					String chsnom =sc.next();
					System.out.println("Saisir le nom du client:");
					String chprenom =sc.next();
					try{System.out.println("Saisir un ca_cumul�e :");
					float ca_cumu = sc.nextFloat();
					Client c1 = new Client(chsnom,chprenom,ca_cumu);
					daof.getClientDAO().create(c1);MenuClient();break;
					}
					catch(InputMismatchException e) {
						System.out.println(InputMismatchException);
						System.out.println(e.getMessage());
					}
					//daof.getFactureDAO().
				
				case 3 : 
					sc = new Scanner(System.in);
					System.out.println("Saisir l'ID du client que vous voulez supprimer:"); 
					Integer id = sc.nextInt();
					Client c3 = new Client(id);
					daof.getClientDAO().delete(c3);MenuClient();break;
				case 4 :
					sc = new Scanner(System.in);
					System.out.println("Saisir l'ID du client que vous voulez modifier:"); 
					Integer id_client = sc.nextInt();
					System.out.println("Saisr le nom du client:");
					String chsnom1 =sc.next();
					System.out.println("Saisir le pr�nom du client:");
					String chprenom1 =sc.next();
					Client c2 = new Client(id_client,chprenom1,chsnom1);
					daof.getClientDAO().update(c2);MenuClient();break;
				
				case 5 : sc = new Scanner(System.in);
				System.out.println("saisir l'ID du Cient que vous voulez voir:"); 
				int td_client2 = sc.nextInt();
				daof.getClientDAO().getById(td_client2);
				MenuClient();
				
				case 6 : m = new Menu();break;
				default: ErreurSaisie();MenuClient();break;
				}
	}
	
	public static void MenuTVA() throws SQLException{
		System.out.println("Tapez 1 pour afficher toutes les valeurs de TVA"
				+ "\nTapez 2 pour ajouter un taux de TVA"
				+ "\nTapez 3 pour supprimer un taux de TVA"
				+ "\nTapez 4 pour modifier un taux de TVA"
				+ "\nTapez 5 pour getById un taux de TVA"
				+ "\nTapez 6 pour revenir au menu principal");
		sc = new Scanner(System.in);
		Integer choix = sc.nextInt();
			switch(choix){
				case 1 : daof.getTVADAO().FindAll();MenuTVA();break;
				case 2 : 
					sc = new Scanner(System.in);
					System.out.println("Saisir le libelle du taux de tva:");
					String s =sc.next();
					
					System.out.println("Saisir le taux de tva:");
					double r =sc.nextDouble();
					
					TVA t = new TVA(s,r);
					daof.getTVADAO().create(t);
					MenuTVA();break;
					
				case 3 : 
					sc = new Scanner(System.in);
					System.out.println("Saisir l'ID du taux de TVA que vous voulez supprimer:"); 
					Integer id_tva = sc.nextInt();
					
					TVA t1 = new TVA(id_tva);
					daof.getTVADAO().delete(t1);
					MenuTVA();break;
					
				case 4 : 
					sc = new Scanner(System.in);
					System.out.println("saisir l'ID du taux de TVA que vous voulez modifier:"); 
					int id_tva1 = sc.nextInt();
					
					System.out.println("Saisir le libelle du taux de tva � modifier:");
					String lib_tva =sc.next();
					
					System.out.println("Saisir le taux de tva � modifier:");
					double t_tva =sc.nextDouble();
					
					TVA t2 = new TVA(id_tva1,lib_tva,t_tva);
					
					daof.getTVADAO().update(t2);
					MenuTVA();break;
					
				case 5 :sc = new Scanner(System.in);
				System.out.println("saisir l'ID du taux de TVA que vous voulez voir:"); 
				int id_tva2 = sc.nextInt();
				daof.getTVADAO().getById(id_tva2);
				MenuTVA();
				break;
				
				
				case 6 : m= new Menu();break;
				default: ErreurSaisie();MenuTVA();break;
			}
	}

	public static void Quitter(){
		System.exit(0);
	}
	public static void ErreurSaisie(){
		System.out.println("Erreur de saisie veuillez r�essayer.");
	}
}
