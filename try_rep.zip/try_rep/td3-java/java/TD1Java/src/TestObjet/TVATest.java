package TestObjet;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import POJO.Produit;
import POJO.TVA;

class TVATest {

	@Test
	public void TestsetId_tva() {
		TVA t=new TVA(1);
		t.setId_tva(2);
		assertNotEquals(1, t.getId_tva());
		}
	@Test
	public void TestsetLibelle_tva() {
		TVA t=new TVA("test");
		t.setLibelle_tva("test2");
		assertNotEquals("test", t.getLibelle_tva());
	}
	@Test
	public void TestsetTaux_tva() {
		TVA t=new TVA(20.0);
		t.setTaux_tva(10.0);
		assertNotEquals(20.0, t.getTaux_tva());
	}

	@Test
	public void TestgetId_tva(){
			TVA t = new TVA();
		    int res_exp = 1; 
		    t.setId_tva(res_exp);
		    int result = t.getId_tva();
		    assertEquals(res_exp, result);
	}
	
	@Test
	public void TestgetLibelle_tva(){
		TVA t = new TVA();
	    String res_exp = "test"; 
	    t.setLibelle_tva(res_exp);
	    String result = t.getLibelle_tva();
	    assertEquals(res_exp, result);
}
	@Test
	public void TestgetTaux_tva() {
		TVA t = new TVA();
	    double res_exp = 20.0; 
	    t.setTaux_tva(res_exp);
	    double result = t.getTaux_tva();
	    assertEquals(res_exp, result);
}

	
	@Test
	public void testConstructeurAttributsCreesOK() {
		TVA t = new TVA(1,"test",20.0);
		assertNotNull(t.getId_tva());
		assertNotNull(t.getLibelle_tva());
		assertNotNull(t.getTaux_tva());
	}
	
	@Test
	public void testConstructeurAttributsCreesVidesOK() {
		TVA t = new TVA();
		assertNull(t.getLibelle_tva());
	}

}
