package TestObjet;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import POJO.Client;

class ClientTest {

	public static boolean isNumeric(String str) {  
		  try {  
		    @SuppressWarnings("unused")
			double s = Double.parseDouble(str);  
		  }  
		  catch(NumberFormatException nfe){  
		    return false;
		    }  
		  return true;
		}
		
		public static boolean isInteger(String s) {
		    try { 
		        Integer.parseInt(s); 
		    } catch(NumberFormatException e) { 
		        return false; 
		    } catch(NullPointerException e) {
		        return false;
		    }
		    return true;
		}
		
		public static boolean isFloat(String s) {
		    try { 
		        Float.parseFloat(s); 
		    } catch(NumberFormatException e) { 
		        return false; 
		    } catch(NullPointerException e) {
		        return false;
		    }
		    return true;
		}
		
		@Test
		public void TestSetNom() {
			Client c=new Client(1, "prenom1","nom1");
			c.setNom("nom2");
			assertNotEquals("nom1", c.getNom());
			}
		@Test
		public void TestsetPrenom() {
			Client c=new Client(1, "prenom1","nom1");
			c.setNom("prenom2");
			assertNotEquals("nom1", c.getPrenom());
		}
		@Test
		public void TestsetId_client() {
			Client c = new Client(1,"prenom1","nom1", 10.1);
			c.setId_client(2);
			assertNotEquals(1, c.getId_client());
		}
		@Test
		public void TestCa_cumule() {
			Client c= new Client(1,"prenom1","nom1",10.1);
			c.setCa_cumule(10.2);
			assertNotEquals(10.1,c.getCa_cumule());
		}
		@Test
		public void TestgetNom(){
			    Client c = new Client();
			    String res_expect = "nom1"; // r�sultat attendu
			    c.setNom("nom1");
			    String result = c.getNom();
			    assertEquals(res_expect, result);
		}
		
		@Test
		public void TestgetPrenom(){
			    Client c = new Client();
			    String res_expect = "prenom1"; // r�sultat attendu
			    c.setPrenom("prenom1");
			    String result = c.getPrenom();
			    assertEquals(res_expect, result);
			}
		@Test
		public void TestgetId_client() {
			 Client c = new Client();
			    int res_expect = 1; // r�sultat attendu
			    c.setId_client(1);
			    int result = c.getId_client();
			    assertEquals(res_expect, result);
		}
		
		@Test
		public void TestgetCa_cumule() {
			 Client c = new Client();
			    double res_expect = 10.0; // r�sultat attendu
			    c.setCa_cumule(10.0);
			    double result = c.getCa_cumule();
			    assertEquals(res_expect, result);
		}
		
		@Test
		public void testConstructeurAttributsCreesOK() {
		Client c = new Client(1, "testpre","testnom",10.0);
		assertNotNull(c.getNom());
		assertNotNull(c.getPrenom());
		assertNotNull(c.getId_client());
		assertNotNull(c.getCa_cumule());
		}
		
		@Test
		public void testConstructeurAttributsCreesVidesOK() {
			Client c = new Client();
			assertNull(c.getNom());
			assertNull(c.getPrenom());
		}

}
