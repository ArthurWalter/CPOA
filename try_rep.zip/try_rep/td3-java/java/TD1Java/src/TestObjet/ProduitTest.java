package TestObjet;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import POJO.Client;
import POJO.Produit;

class ProduitTest {

	@Test
	public void TestsetNom_produit() {
		Produit p=new Produit("testnom",10.1);
		p.setNom_produit("testnom2");
		assertNotEquals("nom1", p.getNom_produit());
		}
	@Test
	public void TestsetPrix_produit() {
		Produit p=new Produit(1,"test",10.1);
		p.setPrix_produit(10.2);
		assertNotEquals(10.1, p.getPrix_produit());
	}
	@Test
	public void TestsetTaux_tva() {
		Produit p=new Produit(1,"test",1);
		p.setTaux_tva(2);
		assertNotEquals(10.1, p.getTaux_tva());
	}
	@Test
	public void TestsetId() {
		Produit p=new Produit(1,"test",10.1);
		p.setId(2);
		assertNotEquals(1, p.getId());
	}
	@Test
	public void TestgetNom_produit(){
			Produit p=new Produit();
		    String res_expect = "nom1"; // r�sultat attendu
		    p.setNom_produit("nom1");
		    String result = p.getNom_produit();
		    assertEquals(res_expect, result);
	}
	
	@Test
	public void TestgetPrix_produit(){
		Produit p=new Produit();
		double res_exp = 10.2;
		    p.setPrix_produit(res_exp);
		    double result = p.getPrix_produit();
		    assertEquals(res_exp, result);
		}
	@Test
	public void TestgetId() {
		Produit p=new Produit();
		    int res_exp = 1; // r�sultat attendu
		    p.setId(res_exp);
		    int result = p.getId();
		    assertEquals(res_exp, result);
	}
	
	@Test
	public void TestgetTaux_tva() {
		Produit p=new Produit();
		  int res_exp = 1; // r�sultat attendu
		    p.setTaux_tva(res_exp);
		    int result = p.getTaux_tva();
		    assertEquals(res_exp, result);
	}
	
	@Test
	public void testConstructeurAttributsCreesOK() {
		Produit p=new Produit(1,"test",10.1);
	assertNotNull(p.getNom_produit());
	assertNotNull(p.getPrix_produit());
	assertNotNull(p.getTaux_tva());
	}
	
	@Test
	public void testConstructeurAttributsCreesVidesOK() {
		Produit p=new Produit();
		assertNull(p.getNom_produit());
	}

}
