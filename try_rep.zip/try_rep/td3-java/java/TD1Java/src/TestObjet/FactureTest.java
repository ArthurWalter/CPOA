package TestObjet;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class FactureTest {

	@Test
	void test() {
		fail("Not yet implemented");
	}//test

}
