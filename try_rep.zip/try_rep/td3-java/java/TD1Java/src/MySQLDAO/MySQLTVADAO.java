package MySQLDAO;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.InputMismatchException;

import Connexion.ConnectionMySQL;
import Connexion.Connexion;
import DAO.TVADAO;
import POJO.TVA;


public class MySQLTVADAO extends Connexion implements TVADAO{
	private static MySQLTVADAO instance;
	private ArrayList<TVA> tab_tva = new ArrayList <TVA>();;
	public static PreparedStatement reqtva;
	
	private MySQLTVADAO(){

	}
	public static MySQLTVADAO getInstance(){
		if(instance==null){
			instance=new MySQLTVADAO();
		}
		return instance;
	}
	
//	@Override
	public TVA getById(int id_tva) throws SQLException{
		String str="select * from tva where id_tva=?";
		tab_tva.clear();
		reqtva = ConnectionMySQL.con.prepareStatement(str);
		
		reqtva.setInt(1, id_tva);
		ResultSet res=reqtva.executeQuery();
			
			while(res.next()) {
				Integer res1=res.getInt("id_tva");
				Double res2=res.getDouble("taux_tva");
				String res3=res.getString("libelle_tva");
				TVA t = new TVA(res1,res3,res2);
				tab_tva.add(t);
			}
			for(TVA s: tab_tva) {//afficher tous les elements de ArrayList
				System.out.println(s);
	}
			return null;
	}
	@Override
	public void create(TVA t) throws SQLException {
		String str = "insert into tva (libelle_tva,taux_tva) values(?,?)";
		reqtva = ConnectionMySQL.con.prepareStatement(str); 
		reqtva.setString(1, t.getLibelle_tva());
		reqtva.setLong(2, (long) t.getTaux_tva());
		reqtva.executeUpdate();
	}
	@Override
	public void update(TVA t) throws SQLException {
		String str ="update tva set libelle_tva = ?, taux_tva= ?  where id_tva=?";
		reqtva = ConnectionMySQL.con.prepareStatement(str); 
		reqtva.setInt(3,t.getId_tva());
		reqtva.setString(1, t.getLibelle_tva());
		reqtva.setDouble(2,t.getTaux_tva());
		reqtva.executeUpdate();
}
	@Override
	public void delete(TVA t) throws SQLException {
		String str ="delete from tva where id_tva=?";
		reqtva = ConnectionMySQL.con.prepareStatement(str);
		reqtva.setInt(1, t.getId_tva());
		reqtva.executeUpdate();
	}
	
	
	@Override
	public ArrayList<TVA> FindAll() throws SQLException{
		this.tab_tva = new ArrayList <TVA>();
		String str="select * from tva";
		reqtva = ConnectionMySQL.con.prepareStatement(str);
		ResultSet res =  reqtva.executeQuery();
		System.out.println("-----------------------------------------");
		System.out.println("|ID\t|Libelle TVA\t\t|Taux\t|");
		System.out.println("-----------------------------------------");
			while (res.next()){
				Integer no1 = res.getInt(1);
				String no2 = res.getString(2);
				Double no3 = res.getDouble(3);
				TVA t = new TVA(no1,no2,no3);
				System.out.println("|"+no1+"\t|"+no2+"\t|"+no3+" %\t|");
				tab_tva.add(t);
			}
		System.out.println("-----------------------------------------");
		return this.tab_tva;
	}

}
