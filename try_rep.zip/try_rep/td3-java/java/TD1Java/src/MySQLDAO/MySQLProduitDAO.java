package MySQLDAO;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.InputMismatchException;

import Connexion.ConnectionMySQL;
import DAO.ProduitDAO;
import POJO.Produit;
public class MySQLProduitDAO implements ProduitDAO {
		private static MySQLProduitDAO instance;
		private ArrayList<Produit> tab_prod = new ArrayList <Produit>();;
		public static PreparedStatement reqprod;
		
		private MySQLProduitDAO(){

		}
		public static MySQLProduitDAO getInstance(){
			if(instance==null){
				instance=new MySQLProduitDAO();
			}
			return instance;
		}
		
//		@Override
		public Produit getById(int id_produit) throws SQLException{
			String str1="select id_produit,libelle_produit,prix_produit,id_tva from produit where id_produit=?";
			tab_prod.clear();
			PreparedStatement requete0=ConnectionMySQL.con.prepareStatement(str1);
			requete0.setInt(1, id_produit);
			ResultSet resset=requete0.executeQuery();
				
				while(resset.next()) {
					Integer res1=resset.getInt("id_produit");
					Double res3=resset.getDouble("prix_produit");
					String res2=resset.getString("libelle_produit");
					int res4 = resset.getInt("id_tva");
					Produit p = new Produit(res1,res2,res3,res4);
					tab_prod.add(p);
				}
				for(Produit s: tab_prod) {//afficher tous les elements de ArrayList
					System.out.println(s);
		}
				return null;
		}
		@Override
		public void create(Produit p) throws SQLException {
				 reqprod = ConnectionMySQL.con.prepareStatement("insert into produit (libelle_produit,prix_produit,id_tva) values(?,?,?)",Statement.RETURN_GENERATED_KEYS);
				reqprod.setString(1, p.getNom_produit());
				reqprod.setDouble(2, p.getPrix_produit());
				reqprod.setInt(3, p.getTaux_tva());
				reqprod.executeUpdate();
		}
		@Override
		public void update(Produit p) throws SQLException {
			String str = "update produit set libelle_produit = ?, prix_produit = ?, id_tva = ?  where id_produit=?";
			reqprod =	ConnectionMySQL.con.prepareStatement(str);
			reqprod.setInt(4,p.getId());
			reqprod.setString(1, p.getNom_produit());
			reqprod.setDouble(2,p.getPrix_produit()); // on test avec long pcq avec double �a ne VEUT pas marcher
			reqprod.setInt(3, p.getTaux_tva() );
			reqprod.executeUpdate();
	}
		@Override
		public void delete(Produit p) throws SQLException {
			reqprod = ConnectionMySQL.con.prepareStatement("delete from produit where id_produit=?",Statement.RETURN_GENERATED_KEYS);
			reqprod.setInt(1,p.getId());
			reqprod.executeUpdate();
		}
		
		
		@Override
		public ArrayList<Produit> FindAll() throws SQLException{
			String str = "select * from produit";
			this.tab_prod = new ArrayList <Produit>();
			reqprod=ConnectionMySQL.con.prepareStatement(str);
			ResultSet res=reqprod.executeQuery();
			System.out.println("---------------------------------------------------------");
			System.out.println("|ID\t|Nom produit\t|Prix produit\t|Taux tva\t|");
			System.out.println("---------------------------------------------------------");
				while (res.next()){
					int no  = res.getInt(1);
					String no1 = res.getString(2);
					Double no2 = res.getDouble(3);
					int no3 = res.getInt(4);
					String nores = "|"+no+"\t|"+no1+"\t|"+no2+" �\t\t|"+no3+" %\t\t|";
					System.out.println(nores);
					Produit p =new Produit(no,no1,no2,no3);
					tab_prod.add(p);
					}
			System.out.println("---------------------------------------------------------");
			return this.tab_prod;
		}

	}
