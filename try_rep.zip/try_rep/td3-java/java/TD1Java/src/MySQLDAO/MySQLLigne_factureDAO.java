package MySQLDAO;

public class MySQLLigne_factureDAO {

}
