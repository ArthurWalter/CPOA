package MySQLDAO;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.InputMismatchException;

import Connexion.ConnectionMySQL;
import Connexion.Connexion;
import DAO.FactureDAO;
import POJO.Facture;

public class MySQLFactureDAO extends Connexion implements FactureDAO {
		private static MySQLFactureDAO instance;
		private ArrayList<Facture> tab_facture = new ArrayList <Facture>();;
		public static PreparedStatement reqfact;
		
		private MySQLFactureDAO(){

		}
		public static MySQLFactureDAO getInstance(){
			if(instance==null){
				instance=new MySQLFactureDAO();
			}
			return instance;
		}
		
//		@Override
		public Facture getById(int id_facture) throws SQLException{
			String str="select id_facture,id_client,date_facture from facture where id_facture=?";
			tab_facture.clear();
			reqfact = ConnectionMySQL.con.prepareStatement(str);
			
			reqfact.setInt(1, id_facture);
			ResultSet res=reqfact.executeQuery();
				
				while(res.next()) {
					int res1=res.getInt("id_facture");
					int res2=res.getInt("id_client");
					LocalDate res3=res.getDate("date_facture").toLocalDate();
					Facture f = new Facture(res1,res2,res3);
					
					tab_facture.add(f);
				}
				for(Facture s: tab_facture) {//afficher tous les elements de ArrayList
					System.out.println(s);
		}
				return null;
		}
		@Override
		public void create(Facture f) throws SQLException {
			String str="insert into facture values(?,?,?)";
			reqfact = ConnectionMySQL.con.prepareStatement(str);

			reqfact.setInt(1, f.getId_facture());
			reqfact.setInt(2, f.getId_client());
			reqfact.setDate(3, java.sql.Date.valueOf(f.getDate_facture()));
			reqfact.executeUpdate();
		}
		@Override
		public void update(Facture f) throws SQLException {
			String str = "update facture set id_client = ?, date_facture = ?  where id_facture=?";
			reqfact = ConnectionMySQL.con.prepareStatement(str);
			reqfact.setInt(1, f.getId_client());
			reqfact.setDate(2, java.sql.Date.valueOf(f.getDate_facture()));
			reqfact.setInt(3, f.getId_facture());
			reqfact.executeUpdate();
				System.out.println("Modifi�");
			}
		
		
		@Override
		public void delete(Facture f) throws SQLException {
			String str="selete from facture where id_facture=?";
			reqfact = ConnectionMySQL.con.prepareStatement(str);
			reqfact.setInt(1, f.getId_facture());
			reqfact.executeUpdate();
				System.out.println("Supprim�");
		}
		
		
		@Override
		public ArrayList<Facture> FindAll() throws SQLException{
			this.tab_facture = new ArrayList <Facture>();
			String str = "select * from facture";
			reqfact = ConnectionMySQL.con.prepareStatement(str);
			ResultSet res=reqfact.executeQuery();
			System.out.println("---------------------------------------------------------");
			System.out.println("Id Facture\t|Id Client\t|Date Facture\t|");
			System.out.println("---------------------------------------------------------");
				while (res.next()){
					int no  = res.getInt(1);
					int no1 = res.getInt(2);
					LocalDate no2 = res.getDate(3).toLocalDate();
					String nores = "|"+no+"\t\t|"+no1+"\t\t|"+no2+"\t|";
					System.out.println(nores);
					Facture f = new Facture(no,no1,no2);
					tab_facture.add(f);
					}
			System.out.println("---------------------------------------------------------");
			return this.tab_facture;
		}

	}
