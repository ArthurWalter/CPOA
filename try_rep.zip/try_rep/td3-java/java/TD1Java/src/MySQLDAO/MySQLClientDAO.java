package MySQLDAO;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import Connexion.ConnectionMySQL;
import Connexion.Connexion;
import DAO.ClientDAO;
import POJO.Client;



public class MySQLClientDAO extends Connexion implements ClientDAO{
	private static MySQLClientDAO instance;
	private ArrayList<Client> tab_cl = new ArrayList <Client>();
	@SuppressWarnings("unused")
	public static PreparedStatement reqclient;
	private MySQLClientDAO(){

	}
	public static MySQLClientDAO getInstance(){
		if(instance==null){
			instance=new MySQLClientDAO();
		}
		return instance;
	}
	
//	@Override
	public Client getById(int id_client) throws SQLException{
		String str = "select id_client,prenom,nom,ca_cumule from client where id_client=?";
		reqclient = ConnectionMySQL.con.prepareStatement(str);
		tab_cl.clear();
		reqclient.setInt(1, id_client);
		ResultSet res=reqclient.executeQuery();
			
			while(res.next()) {
				Integer res1=res.getInt("id_client");
				String res2=res.getString("prenom");
				String res3=res.getString("nom");
				Double res4=res.getDouble("ca_cumule");
				Client c=new Client(res1,res2,res3,res4);
				tab_cl.add(c);
			}
			for(Client s: tab_cl) {//afficher tous les elements de ArrayList
				System.out.println(s);
	}
			return null;
	}
	@Override
	public void create(Client c) throws SQLException {
		String str ="insert into client (nom,prenom,ca_cumule) values(?,?,)";
		reqclient = ConnectionMySQL.con.prepareStatement(str);	
		reqclient.setString(1, c.getNom());
		reqclient.setString(2, c.getPrenom());
		reqclient.setDouble(2,c.getCa_cumule());
		reqclient.executeUpdate();
	}
	@Override
	public void update(Client c) throws SQLException {
		String str = "update client set nom = ?, prenom = ?  where id_client=?";
		reqclient = ConnectionMySQL.con.prepareStatement(str);	
		reqclient.setInt(3,c.getId_client());
		reqclient.setString(1, c.getNom());
		reqclient.setString(2, c.getPrenom());
		reqclient.executeUpdate();
	}
	@Override
	public void delete(Client c) throws SQLException {
		String str ="delete from client where id_client=?";
		reqclient = ConnectionMySQL.con.prepareStatement(str);	
		reqclient.setInt(1,c.getId_client());
		reqclient.executeUpdate();
	}
	
	
	@Override
	public ArrayList<Client> FindAll() throws SQLException{
		this.tab_cl = new ArrayList <Client>();
		String str = "select id_client,prenom,nom,ca_cumule from client";
		reqclient = ConnectionMySQL.con.prepareStatement(str);
		ResultSet res=reqclient.executeQuery();
		System.out.println("---------------------------------------------------------");
		System.out.println("|ID\t|Pr�nom\t\t|Nom\t\t|Cumul achats\t|");
		System.out.println("---------------------------------------------------------");
			while (res.next()){
				Integer no1 = res.getInt(1);
				String no2 = res.getString(2);
				String no3 = res.getString(3);
				Double no4 = res.getDouble(4);
				Client c = new Client(no1,no2,no3,no4);
				String nores = "|"+no1+"\t|"+no2+"\t|"+no3+"\t|"+no4+" �\t\t|";
				System.out.println(nores);
				tab_cl.add(c);
				}
		System.out.println("---------------------------------------------------------");
			return this.tab_cl;
	}

}
