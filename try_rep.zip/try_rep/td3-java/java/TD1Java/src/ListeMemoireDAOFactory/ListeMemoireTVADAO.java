package ListeMemoireDAOFactory;

import java.util.ArrayList;

import DAO.TVADAO;
import POJO.TVA;


public class ListeMemoireTVADAO implements TVADAO {

	private static ListeMemoireTVADAO instance;

	private ArrayList<TVA> donnees;

	public static ListeMemoireTVADAO getInstance() {

		if (instance == null) {
			instance = new ListeMemoireTVADAO();
		}

		return instance;
	}

	private ListeMemoireTVADAO() {

		this.donnees = new ArrayList<TVA>();

		this.donnees.add(new TVA(1, "Normal", 20));
		this.donnees.add(new TVA(2, "R�duit", 10));
	}
	
	@Override
	public void create(TVA tva) {

		// gestion de l'auto-incr�ment
		if (this.donnees.size() == 0) {
			tva.setId_tva(0);
		} else {
			int id = this.donnees.get(this.donnees.size() - 1).getId_tva() + 1;
			tva.setId_tva(id);
		}
		
		// ajout du nouvel objet � la liste
		this.donnees.add(tva);
	}
	@Override
	public void update(TVA tva) {

		// Ne fonctionne que si l'objet m�tier est bien fait...
		int idx = tva.getId_tva()-1;
		if (idx == -1) {
			throw new IllegalArgumentException("Tentative de modification d'un objet inexistant");
		} else {
			this.donnees.set(idx, tva);
		}
	}
	
	@Override
	public void delete(TVA tva) {

		// Ne fonctionne que si l'objet m�tier est bien fait...
		int idx = tva.getId_tva()-1;
		if (idx == -1) {
			throw new IllegalArgumentException("Tentative de suppression d'un objet inexistant");
		} else {
			this.donnees.remove(idx);
		}
	}
	
	@Override
	public TVA getById(int id) {

		
		int idx = id-1;
		if (idx == -1) {
			throw new IllegalArgumentException("Aucun objet ne poss�de cet identifiant");
		} else {
			return this.donnees.get(idx);
		}
	}
	
	@Override
	public ArrayList<TVA> FindAll() {
		return this.donnees;
		}
	}


