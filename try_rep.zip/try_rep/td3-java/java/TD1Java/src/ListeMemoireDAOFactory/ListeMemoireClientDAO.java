package ListeMemoireDAOFactory;

import java.sql.SQLException;
import java.util.ArrayList;

import DAO.ClientDAO;
import POJO.Client;


public class ListeMemoireClientDAO implements ClientDAO {

	private static ListeMemoireClientDAO instance;

	private ArrayList<Client> donnees;

	public static ListeMemoireClientDAO getInstance() {

		if (instance == null) {
			instance = new ListeMemoireClientDAO();
		}

		return instance;
	}

	private ListeMemoireClientDAO() {

		this.donnees = new ArrayList<Client>();

		this.donnees.add(new Client(1, "Walter","Arthur",  50.0));
		this.donnees.add(new Client(2, "Palma","Kilian", 30.0));
	}

	public void create(Client objet) {

		// gestion de l'auto-incr�ment
		if (this.donnees.size() == 0) {
			objet.setId_client(0);
		} else {
			int id = this.donnees.get(this.donnees.size() - 1).getId_client() + 1;
			objet.setId_client(id);
		}
		
		// ajout du nouvel objet � la liste
		this.donnees.add(objet);
	}

	public void update(Client objet) {

		
		int idx = this.donnees.indexOf(objet);
		if (idx == -1) {
			throw new IllegalArgumentException("Tentative de modification d'un objet inexistant");
		} else {
			this.donnees.set(idx, objet);
		}
	}

	public void delete(Client objet) {

		
		int idx = this.donnees.indexOf(objet);
		if (idx == -1) {
			throw new IllegalArgumentException("Tentative de suppression d'un objet inexistant");
		} else {
			this.donnees.remove(idx);
		}
	}

	public Client getById(int id) {

		
		int idx = this.donnees.indexOf(new Client(id, "test nom","test prenom", 0));
		if (idx == -1) {
			throw new IllegalArgumentException("Aucun objet ne poss�de cet identifiant");
		} else {
			return this.donnees.get(idx);
		}
	}

	public ArrayList<Client> FindAll() {
		return this.donnees;
	}
}
