package ListeMemoireDAOFactory;

import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

import DAO.FactureDAO;
import POJO.Facture;

public class ListeMemoireFactureDAO implements FactureDAO {

	private static ListeMemoireFactureDAO instance;

	private ArrayList<Facture> donnees;

	public static ListeMemoireFactureDAO getInstance() {

		if (instance == null) {
			instance = new ListeMemoireFactureDAO();
		}

		return instance;
	}

	private ListeMemoireFactureDAO() {

		this.donnees = new ArrayList<Facture>();
		DateTimeFormatter format_date = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		LocalDate dateDebut = LocalDate.parse("27/09/2018", format_date);
		this.donnees.add(new Facture(1, 1, dateDebut));
		this.donnees.add(new Facture(2, 2, dateDebut));
	}

	public void create(Facture objet) {

		// gestion de l'auto-incr�ment
		if (this.donnees.size() == 0) {
			objet.setId_facture(0);
		} else {
			int id_facture = this.donnees.get(this.donnees.size() - 1).getId_facture() + 1;
			objet.setId_facture(id_facture);
		}
		
		// ajout du nouvel objet � la liste
		this.donnees.add(objet);
	}

	public void update(Facture objet) {

		// Ne fonctionne que si l'objet m�tier est bien fait...
		int idx = objet.getId_facture()-1;
		if (idx == -1) {
			throw new IllegalArgumentException("Tentative de modification d'un objet inexistant");
		} else {
			this.donnees.set(idx, objet);
		}
	}

	public void delete(Facture objet) {

		// Ne fonctionne que si l'objet m�tier est bien fait...
		int idx = objet.getId_facture()-1;
		if (idx == -1) {
			throw new IllegalArgumentException("Tentative de suppression d'un objet inexistant");
		} else {
			this.donnees.remove(idx);
		}
	}

	public Facture getById(int id_facture) {

		// Ne fonctionne que si l'objet m�tier est bien fait...
		
		DateTimeFormatter format_date = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		LocalDate dateDebut = LocalDate.parse("27/09/2018", format_date);
	//	int idx = this.donnees.indexOf(new Facture(id_facture, id_client, dateDebut));
		int idx = id_facture-1;
		if (idx == -1) {
			throw new IllegalArgumentException("Aucun objet ne poss�de cet identifiant");
		} else {
			return this.donnees.get(idx);
		}
	}

	public void findAll() {
		for(Facture x: this.donnees) {
			System.out.println(x.toString());
		}
	}

	@Override
	public ArrayList<Facture> FindAll() throws SQLException {
		return this.donnees;
		
	}

}
