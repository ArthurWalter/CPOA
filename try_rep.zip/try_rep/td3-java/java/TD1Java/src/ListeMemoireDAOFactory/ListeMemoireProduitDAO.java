package ListeMemoireDAOFactory;

import java.sql.SQLException;
import java.util.ArrayList;

import DAO.ProduitDAO;
import POJO.Produit;


public class ListeMemoireProduitDAO implements ProduitDAO {

	private static ListeMemoireProduitDAO instance;

	private ArrayList<Produit> donnees;

	public static ListeMemoireProduitDAO getInstance() {

		if (instance == null) {
			instance = new ListeMemoireProduitDAO();
		}

		return instance;
	}

	private ListeMemoireProduitDAO() {

		this.donnees = new ArrayList<Produit>();

		this.donnees.add(new Produit(1, "test1",  10.0, 1));
		this.donnees.add(new Produit(2, "test2",  10.0, 2));
	}

	public void create(Produit objet) {

		// gestion de l'auto-incr�ment
		if (this.donnees.size() == 0) {
			objet.setId(0);
		} else {
			int id = this.donnees.get(this.donnees.size() - 1).getId() + 1;
			objet.setId(id);
		}
		
		// ajout du nouvel objet � la liste
		this.donnees.add(objet);
	}

	public void update(Produit objet) {

		// Ne fonctionne que si l'objet m�tier est bien fait...
		int idx = objet.getId()-1;
		if (idx == -1) {
			throw new IllegalArgumentException("Tentative de modification d'un objet inexistant");
		} else {
			this.donnees.set(idx, objet);
		}
	}

	public void delete(Produit objet) {

		// Ne fonctionne que si l'objet m�tier est bien fait...
		int idx = objet.getId()-1;
		if (idx == -1) {
			throw new IllegalArgumentException("Tentative de suppression d'un objet inexistant");
		} else {
			this.donnees.remove(idx);
		}
	}

	public Produit getById(int id) {

		
		int idx = id-1;
		if (idx == -1) {
			throw new IllegalArgumentException("Aucun objet ne poss�de cet identifiant");
		} else {
			return this.donnees.get(idx);
		}
	}

	@Override
	public ArrayList<Produit> FindAll() throws SQLException {
		return this.donnees;
		}
	}


