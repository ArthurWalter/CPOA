package ListeMemoireDAOFactory;

public class ListeMemoireLigne_FactureDAO {

}
