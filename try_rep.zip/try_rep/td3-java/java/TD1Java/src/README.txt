﻿Kilian : 45%
- jeu de données BdD
-TD2 : Pojo
-TD3 : test des Pojo
-TD4 : création et gestion de la fenetre.fxml
-après TD4 : gestion des erreurs dans ctrl_Produit
-après TD4 : Les 5 fenetres fxml (accueil, produit, tva, client, facture)


Arthur : 55%
-TD1 : création et gestion des premiers CRUD (= méthodes create update delete) (TD1), Connexion à la BdD sur Putty.
-TD2 : création et gestion des DAOFactory (et tout ce qui est en lien)
-TD2 : ListeMémoireDAO, MySQLDAO, nouvelle connexion(properties), jeu de données ListeMemoireDAO
-TD3 : test des classes MySQLDAO, ListeMémoireDAO (pas vraiment opérationnels)
-TD4 : gestion de la combo box de TVA, gestion des entrées dans les Edit pour l'affichage dans le Label résultat
-TD4 : gestion des Edit pour créer des objets Produit
-après TD4 : gestion des méthodes CRUD dans l'ensemble des classes controleur (ctrl_Produit etc..), des tableview.
-après TD4 : gestion du nouveau menu
-après TD4 : gestion des images

Lors de la première exécution, l'utilisateur va devoir choisir entre se connecter à la base donnée ou travailler hors ligne avec la liste mémoire;
Ce choix est définitif.

Ce qui fonctionne :
- la connexion à la base de donnée (paramétrée via Putty, par mesure pratique car nous travaillions sur des machines personnelles)
- les méthodes create, update, delete pour toutes les classes
- récupérer les données des deux bases; la base de données en ligne et la liste mémoire en local
- ajouter, modifier, supprimer des données dans les deux bases
- gestion d'une image d'aperçu pour les 9 premiers produits
- les erreurs liées au contrôleur du produit sont gérées

Ce qui ne fonctionne pas :
- ligne_facture n'est pas utilisée, car nous n'avons pas réussi à gérer la hashmap
- mauvaise optimisation pour les fenêtres qui peuvent planter pour des raisons obscures
- le type double n'a pas été géré correctement coté base de données, il est donc impossible de saisir des nombres à virgule dans l'application
- toutes erreurs ne sont pas gérées

Il existe 2 main dans le projet : l'un se situant dans le package application, qui est la version finale concernant les fichiers fxml et l'affichage graphique.
L'autre se situant dans le package menu, et qui permet d'accéder à la version console de Eclipse.
