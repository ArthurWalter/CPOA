package DAO;

import POJO.Client;

public interface ClientDAO extends DAO<Client>{

}
/*import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Scanner;

public class ClientDAO extends Connexion{
	private ArrayList<String> tab_cl;
	private Scanner sc;
	private Scanner sc2;
	private Scanner sc3;
	@SuppressWarnings("unused")
	private Statement requete;
	@SuppressWarnings("unused")
	private Statement requete2;
	@SuppressWarnings("unused")
	private Statement requete3;
	
	public void add(String o){
		tab_cl.add(o);
	}

	public void AfficherAR() throws SQLException{
		this.tab_cl = new ArrayList <String>();
		Connection laConnexion = creeConnexion();
		Statement requete = laConnexion.createStatement();
		ResultSet res =  requete.executeQuery("select id_client,prenom,nom,ca_cumule from client ");
		System.out.println("---------------------------------------------------------");
		System.out.println("|ID\t|Pr�nom\t\t|Nom\t\t|Cumul achats\t|");
		System.out.println("---------------------------------------------------------");
			while (res.next()){
				String no1 = res.getString(1);
				String no2 = res.getString(2);
				String no3 = res.getString(3);
				String no4 = res.getString(4);
				String nores = "|"+no1+"\t|"+no2+"\t|"+no3+"\t|"+no4+" �\t\t|";
				System.out.println(nores);
				tab_cl.add(nores);
				}
		System.out.println("---------------------------------------------------------");
	}
	
	public void supprimerClient(Client c) throws SQLException{
		Connection laConnexion = creeConnexion();
		requete = laConnexion.createStatement();
		PreparedStatement reqclient = laConnexion.prepareStatement("delete from client where id_client=?",Statement.RETURN_GENERATED_KEYS);
		reqclient.setInt(1,c.getId_client());
		reqclient.executeUpdate();
	}

	public void modifierClient(Client c) throws SQLException{
		 Connection laConnexion = creeConnexion();
			requete3 = laConnexion.createStatement();
			PreparedStatement reqclient = laConnexion.prepareStatement("update client set nom = ?, prenom = ?  where id_client=?",Statement.RETURN_GENERATED_KEYS);
			reqclient.setInt(3,c.getId_client());
			reqclient.setString(1, c.getNom());
			reqclient.setString(2, c.getPrenom());
			reqclient.executeUpdate();
	}

	public void ajouterClient(Client c) throws SQLException{
		 Connection laConnexion = creeConnexion();
			requete2 = laConnexion.createStatement();
			PreparedStatement reqclient = laConnexion.prepareStatement("insert into client (nom,prenom,ca_cumule) values(?,?,)",Statement.RETURN_GENERATED_KEYS);
			reqclient.setString(1, c.getNom());
			reqclient.setString(2, c.getPrenom());
			reqclient.setDouble(3, c.getCa_cumule());
			reqclient.executeUpdate();
	}
}
*/