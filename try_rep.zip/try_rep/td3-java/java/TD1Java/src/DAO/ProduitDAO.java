package DAO;

import POJO.Produit;

public interface ProduitDAO extends DAO<Produit>{

}
/*import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Scanner;

public class ProduitDAO extends Connexion{
	private ArrayList<String> tab_prod;
	private Scanner sc;
	private Scanner sc2;
	private Scanner sc3;
	private Scanner sc4;
	private Scanner sc5;
	@SuppressWarnings("unused")
	private Statement requete;
	@SuppressWarnings("unused")
	private Statement requete2;
	
	public void add(String o){
		tab_prod.add(o);
	}

	public void AfficherAR() throws SQLException{
		this.tab_prod = new ArrayList <String>();
		Connection laConnexion = creeConnexion();
		Statement requete = laConnexion.createStatement();
		ResultSet res =  requete.executeQuery("select id_produit,libelle_produit,prix_produit,taux_tva from produit,tva where produit.id_tva=tva.id_tva");
		System.out.println("---------------------------------------------------------");
		System.out.println("|ID\t|Nom produit\t|Prix produit\t|Taux tva\t|");
		System.out.println("---------------------------------------------------------");
			while (res.next()){
				String no  = res.getString(1);
				String no1 = res.getString(2);
				String no2 = res.getString(3);
				String no3 = res.getString(4);
				String nores = "|"+no+"\t|"+no1+"\t|"+no2+" �\t\t|"+no3+" %\t\t|";
				System.out.println(nores);
				tab_prod.add(nores);
				}
		System.out.println("---------------------------------------------------------");
	}

	public void DeleteProduit(Produit p) throws SQLException{
		Connection laConnexion = creeConnexion();
		requete = laConnexion.createStatement();
		PreparedStatement reqprod = laConnexion.prepareStatement("delete from produit where id_produit=?",Statement.RETURN_GENERATED_KEYS);
		reqprod.setInt(1,p.getId());
		reqprod.executeUpdate();
	}

	public void updateProduit(Produit p) throws SQLException{
		Connection laConnexion = creeConnexion();
		requete2 = laConnexion.createStatement();
		PreparedStatement reqprod =	laConnexion.prepareStatement("update produit set libelle_produit = ?, prix_produit = ?, id_tva = ?  where id_produit=?",Statement.RETURN_GENERATED_KEYS);
		reqprod.setInt(4,p.getId());
		reqprod.setString(1, p.getNom_produit());
		reqprod.setLong(2, (long) p.getPrix_produit()); // on test avec long pcq avec double �a ne VEUT pas marcher
		reqprod.setInt(3, p.getTaux_tva() );
		reqprod.executeUpdate();
	}

	public void ajouterProduit(Produit p) throws SQLException{
		 Connection laConnexion = creeConnexion();
			PreparedStatement reqprod = laConnexion.prepareStatement("insert into produit (libelle_produit,prix_produit,id_tva) values(?,?,?)",Statement.RETURN_GENERATED_KEYS);
			reqprod.setString(1, p.getNom_produit());
			reqprod.setLong(2, (long) p.getPrix_produit());
			reqprod.setInt(3, p.getTaux_tva());
			reqprod.executeUpdate();
	}
}
*/