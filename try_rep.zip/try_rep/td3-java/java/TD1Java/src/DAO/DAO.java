package DAO;

import java.sql.SQLException;
import java.util.ArrayList;
public interface DAO<O> {
public abstract O getById(int id) throws SQLException;
public abstract void create(O objet) throws SQLException;
public abstract void update(O objet) throws SQLException;
public abstract void delete(O Objet) throws SQLException;
public abstract ArrayList<O> FindAll() throws SQLException;
}

