package DAO;

public class Ligne_FactureDAO {

}
