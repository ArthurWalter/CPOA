package DAO;

import DAOFactory.DAOFactory;
import MySQLDAO.MySQLClientDAO;
import MySQLDAO.MySQLFactureDAO;
import MySQLDAO.MySQLProduitDAO;
import MySQLDAO.MySQLTVADAO;

public class ListeMemoireDAO extends DAOFactory{

	@Override
	public TVADAO getTVADAO() {
		return MySQLTVADAO.getInstance();
	}
	
	@Override
	public ClientDAO getClientDAO() {
		return MySQLClientDAO.getInstance();
	}
	
	@Override
	public ProduitDAO getProduitDAO() {
		return MySQLProduitDAO.getInstance();
	}
	
	@Override
	public FactureDAO getFactureDAO() {
		return MySQLFactureDAO.getInstance();
	}
}