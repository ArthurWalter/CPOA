package DAO;

import POJO.Facture;

public interface FactureDAO extends DAO<Facture>{

}
/*import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Scanner;

@SuppressWarnings("unused")
public class FactureDAO extends Connexion{
	private ArrayList<String> tab_prod;
	private Scanner sc;
	private Scanner sc2;
	private Scanner sc3;
	private Scanner sc4;
	private Scanner sc5;
	@SuppressWarnings("unused")
	private Statement requete;
	@SuppressWarnings("unused")
	private Statement requete2;
	
	public void add(String o){
		tab_prod.add(o);
	}

	public void AfficherAR() throws SQLException{
		this.tab_prod = new ArrayList <String>();
		Connection laConnexion = creeConnexion();
		Statement requete = laConnexion.createStatement();
		ResultSet res =  requete.executeQuery("select id_facture,id_client,date_facture from facture");
		System.out.println("---------------------------------------------------------");
		System.out.println("|ID facture\t|ID client\t|Date Facture\t|");
		System.out.println("---------------------------------------------------------");
			while (res.next()){
				String no  = res.getString(1);
				String no1 = res.getString(2);
				LocalDate no2 = res.getDate(3).toLocalDate();
				DateTimeFormatter format_date = DateTimeFormatter.ofPattern("dd/MM/yyyy");
				String no3 = no2.format(format_date);
				String nores = "|"+no+"\t|"+no1+"\t|"+no2+"\t|";
				System.out.println(nores);
				tab_prod.add(nores);
				}
		System.out.println("---------------------------------------------------------");
	}

	public void supprimerFacture() throws SQLException{
		Connection laConnexion = creeConnexion();
		requete = laConnexion.createStatement();
		PreparedStatement reqfact = laConnexion.prepareStatement("delete from facture where id_facture=?",Statement.RETURN_GENERATED_KEYS);
		sc = new Scanner(System.in);
		System.out.println("Saisir l'ID de la facture que vous voulez supprimer:"); 
		Integer id = sc.nextInt();
		reqfact.setInt(1,id);
		reqfact.executeUpdate();
	}
	
	public void modifierFacture() throws SQLException{
		Connection laConnexion = creeConnexion();
		requete2 = laConnexion.createStatement();
		PreparedStatement reqfact =	laConnexion.prepareStatement("update produit set id_client = ?, date_facture = ?  where id_facture=?",Statement.RETURN_GENERATED_KEYS);
		sc2 = new Scanner(System.in);
		sc3 = new Scanner(System.in);
		System.out.println("Saisir l'ID de la facture que vous voulez modifier:"); 
		Integer id_facture = sc2.nextInt();
		reqfact.setInt(3,id_facture);
		System.out.println("Saisir l'id du client:");
		Integer id_client =sc2.nextInt();
		System.out.println("Saisir la date de la facture :");
		String date_facture =sc3.nextLine();
		DateTimeFormatter format_date = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		LocalDate dateDeb = LocalDate.parse(date_facture, format_date);
		reqfact.setInt(3, id_facture);
		reqfact.setDate(2, java.sql.Date.valueOf(dateDeb));
		reqfact.setInt(1, id_client);
		reqfact.executeUpdate();
	}

	public void ajouterFacture() throws SQLException{
			Connection laConnexion = creeConnexion();
			PreparedStatement reqfact = laConnexion.prepareStatement("insert into facture values(?,?,?)",Statement.RETURN_GENERATED_KEYS);
			sc4 = new Scanner(System.in);
			sc5 = new Scanner(System.in);
			System.out.println("Saisir l'id de la facture:");
			Integer id_facture =sc4.nextInt();
			System.out.println("Saisir l'id du client:");
			Integer id_client =sc4.nextInt();
			System.out.println("Saisir la date de la facture:");
			String date_facture = sc5.nextLine();
			DateTimeFormatter format_date = DateTimeFormatter.ofPattern("dd/MM/yyyy");
			LocalDate dateDebut = LocalDate.parse(date_facture, format_date);
			reqfact.setInt(1, id_facture);
			reqfact.setInt(2, id_client);
			reqfact.setDate(3, java.sql.Date.valueOf(dateDebut));
			reqfact.executeUpdate();	 
	}
}
*/