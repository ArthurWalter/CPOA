package DAO;

import POJO.TVA;

public interface TVADAO extends DAO<TVA>{

}


/*package Start;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.*;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class TVADAO extends Connexion{
	private ArrayList<String> tab_tva;
	private Scanner sc;
	private Scanner sc2;
	private Scanner sc3;
	@SuppressWarnings("unused")
	private Statement requete;
	@SuppressWarnings("unused")
	private Statement requete2;
	@SuppressWarnings("unused")
	private Statement requete3;
	
	public void add(String o){
		tab_tva.add(o);
	}

	public void AfficherAR() throws SQLException{
		this.tab_tva = new ArrayList <String>();
		Connection laConnexion = creeConnexion();
		Statement requete = laConnexion.createStatement();
		ResultSet res =  requete.executeQuery("select id_tva,libelle_tva, taux_tva from tva ");
		System.out.println("-----------------------------------------");
		System.out.println("|ID\t|Libelle TVA\t\t|Taux\t|");
		System.out.println("-----------------------------------------");
			while (res.next()){
				Integer no1 = res.getInt(1);
				String no2 = res.getString(2);
				String no3 = res.getString(3);
				System.out.println("|"+no1+"\t|"+no2+"\t|"+no3+" %\t|");
				tab_tva.add(no3);
			}
		System.out.println("-----------------------------------------");
	}

	public void ajouterTVA(TVA t) throws SQLException{
		 Connection laConnexion = creeConnexion();
			requete3 = laConnexion.createStatement();
			PreparedStatement reqtva = laConnexion.prepareStatement("insert into tva (libelle_tva,taux_tva) values(?,?)",Statement.RETURN_GENERATED_KEYS);
			
			reqtva.setString(1, t.getLibelle_tva());
			reqtva.setLong(2, (long) t.getTaux_tva());
			reqtva.executeUpdate();
	}
	
	public void modifierTVA(TVA t) throws SQLException{
		 Connection laConnexion = creeConnexion();
			requete2 = laConnexion.createStatement();
			PreparedStatement reqtva = laConnexion.prepareStatement("update tva set libelle_tva = ?, taux_tva= ?  where id_tva=?",Statement.RETURN_GENERATED_KEYS);
			
			reqtva.setInt(3,t.getId_tva());
			reqtva.setString(1, t.getLibelle_tva());
			reqtva.setDouble(2,t.getTaux_tva());
			reqtva.executeUpdate();
	}
	
	public void supprimerTVA(TVA t) throws SQLException{
		Connection laConnexion = creeConnexion();
		requete = laConnexion.createStatement();
		PreparedStatement reqtva = laConnexion.prepareStatement("delete from tva where id_tva=?",Statement.RETURN_GENERATED_KEYS);
		reqtva.setInt(1, t.getId_tva());
		reqtva.executeUpdate();
	}
}*/